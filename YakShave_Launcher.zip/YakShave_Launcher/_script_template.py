#!/usr/bin/env python3
"""
Name: My New Tool
Category: General
Description: One clear sentence about what this does. It shows up on the card
    in the launcher, so keep it short and concrete.
Author: Yak Shave
Version: 1.0
Tags: example, template
Args: --help
Requires: nothing

Copy this file, rename it, and edit the header above. The launcher picks it up
the moment you save it - nothing has to be registered anywhere.
"""

from __future__ import annotations

import argparse
import sys


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="What this tool does.")
    parser.add_argument("--input", help="Folder or file to work on.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would happen without touching anything.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    # print(..., flush=True) keeps the launcher console live instead of
    # dumping everything at the end.
    print("Starting", flush=True)

    if args.dry_run:
        print("Dry run - nothing was changed.", flush=True)

    print("Done.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
