#!/usr/bin/env python3
"""
Yak Shave Launcher
==================

A single-window control centre for your local scripts.

Point it at one or more folders, and every script inside shows up as a card:
sorted, searchable, categorised, favouritable, and one click away from running.
The launcher itself never needs to be edited when you add a new script - it
reads what it needs from a short metadata header inside the script file.

    # Name: Watermark Batch
    # Category: Images
    # Description: Applies an adaptive watermark to every image in a folder.
    # Tags: batch, images
    # Version: 1.2

See SCRIPT_METADATA.md for the full specification.

Yak Shave - lightweight, no-bullshit CLI tools and Python scripts for power users.
"""

from __future__ import annotations

import json
import logging
import math
import os
import platform
import re
import shlex
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from PySide6.QtCore import (
        QEvent,
        QFileSystemWatcher,
        QPoint,
        QProcess,
        QProcessEnvironment,
        QSize,
        Qt,
        QTimer,
        Signal,
    )
    from PySide6.QtGui import (
        QAction,
        QColor,
        QCursor,
        QDesktopServices,
        QFont,
        QFontDatabase,
        QIcon,
        QKeySequence,
        QPainter,
        QPainterPath,
        QPalette,
        QPen,
        QPixmap,
        QShortcut,
    )
    from PySide6.QtCore import QUrl
    from PySide6.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QDialog,
        QDialogButtonBox,
        QFileDialog,
        QFrame,
        QGridLayout,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QListWidget,
        QListWidgetItem,
        QMainWindow,
        QMenu,
        QMessageBox,
        QPlainTextEdit,
        QProxyStyle,
        QPushButton,
        QScrollArea,
        QSizePolicy,
        QSplitter,
        QStyle,
        QTabBar,
        QTabWidget,
        QToolButton,
        QVBoxLayout,
        QWidget,
    )
except ImportError:  # pragma: no cover - startup guard
    sys.stderr.write(
        "Yak Shave Launcher needs PySide6.\n\n"
        "Install it with:\n    pip install PySide6\n"
    )
    raise SystemExit(1)


APP_NAME = "Yak Shave"
APP_TAGLINE = "Lightweight, no-bullshit tools for power users."
APP_VERSION = "1.3.0"
CONFIG_FILENAME = "yakshave_config.json"
# Every Yak Shave tool writes its configs, caches and backups into this one
# folder instead of dropping loose files next to the scripts.
DATA_DIR_NAME = "yakshave_data"

SCRIPT_EXTENSIONS = {
    ".py": "python",
    ".pyw": "python",
    ".bat": "batch",
    ".cmd": "batch",
    ".ps1": "powershell",
    ".sh": "shell",
}

KIND_LABELS = {
    "python": "PY",
    "batch": "BAT",
    "powershell": "PS1",
    "shell": "SH",
}

IGNORED_DIR_NAMES = {
    DATA_DIR_NAME,
    "__pycache__",
    ".git",
    ".svn",
    ".hg",
    ".idea",
    ".vscode",
    "venv",
    ".venv",
    "env",
    "node_modules",
    "site-packages",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
}

UNCATEGORISED = "Uncategorised"

VIEW_ALL = "__all__"
SUITE_PREFIX = "suite:"     # sidebar key for one suite's own view
VIEW_FAVOURITES = "__favourites__"
VIEW_RECENT = "__recent__"
VIEW_SCHEDULE = "__schedule__"      # opens the release schedule, not a list view
SCHEDULE_PREFIX = "yakshave_schedule_"

SORT_MODES = [
    ("modified", "Date modified"),
    ("name", "Name (A-Z)"),
    ("category", "Category"),
    ("lastrun", "Last run"),
    ("runs", "Times run"),
]


# --------------------------------------------------------------------------
# Theme
# --------------------------------------------------------------------------

class Theme:
    """Central colour and metric definitions. Change the accent here."""

    BG = "#0E0F11"
    BG_ALT = "#131519"
    SURFACE = "#1A1D22"
    SURFACE_HOVER = "#21252B"
    SURFACE_ACTIVE = "#272C33"
    BORDER = "#2A2F37"
    BORDER_STRONG = "#3A414B"

    TEXT = "#E9EBEE"
    TEXT_DIM = "#9AA2AD"
    TEXT_MUTED = "#69707A"

    ACCENT = "#FF7A18"
    ACCENT_HOVER = "#FF9038"
    ACCENT_PRESSED = "#E2660B"
    ACCENT_SOFT = "#3A2412"

    OK = "#54D98C"
    ERROR = "#F2686B"
    WARN = "#EFC15C"

    RADIUS = 8
    RADIUS_SM = 6


def mono_font(size: int = 10) -> QFont:
    """A monospace font that exists on Windows, macOS and Linux."""
    for family in ("Cascadia Mono", "Consolas", "Menlo", "DejaVu Sans Mono", "Courier New"):
        if family in QFontDatabase.families():
            font = QFont(family, size)
            font.setStyleHint(QFont.Monospace)
            return font
    font = QFont()
    font.setStyleHint(QFont.Monospace)
    font.setPointSize(size)
    return font


def ui_font(size: int = 10, bold: bool = False) -> QFont:
    for family in ("Segoe UI", "Inter", "SF Pro Text", "Ubuntu", "DejaVu Sans"):
        if family in QFontDatabase.families():
            font = QFont(family, size)
            font.setBold(bold)
            return font
    font = QFont()
    font.setPointSize(size)
    font.setBold(bold)
    return font


# --------------------------------------------------------------------------
# Persistent configuration and state
# --------------------------------------------------------------------------

def data_dir() -> Path:
    """The folder Yak Shave writes into, created on first use.

    `yakshave_data` next to the launcher by default; override it with the
    YAKSHAVE_DATA_DIR environment variable; falls back to ~/.yakshave when
    the launcher's own folder is read-only. The tools use the same rule, so
    everything lands in one place.
    """
    candidates = []
    override = os.environ.get("YAKSHAVE_DATA_DIR")
    if override:
        candidates.append(Path(override).expanduser())
    candidates.append(Path(__file__).resolve().parent / DATA_DIR_NAME)
    candidates.append(Path.home() / ".yakshave")
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            return candidate
        except OSError:
            continue
    return Path(__file__).resolve().parent


def default_config_path() -> Path:
    """The settings file, moved in from beside the launcher if an older
    version left one there."""
    target = data_dir() / CONFIG_FILENAME
    legacy = Path(__file__).resolve().parent / CONFIG_FILENAME
    if legacy != target and legacy.is_file() and not target.exists():
        try:
            legacy.replace(target)
        except OSError:
            pass
    return target


# --------------------------------------------------------------------------
# Log - everything the launcher does, so a problem can be diagnosed from the
# file instead of guessed at. Settings -> "Open log" shows it.
# --------------------------------------------------------------------------

LOG = logging.getLogger("yakshave")


def log_path() -> Path:
    return data_dir() / "yakshave_launcher.log"


def setup_logging() -> None:
    """One file, capped at ~1 MB with one previous copy kept."""
    from logging.handlers import RotatingFileHandler
    if LOG.handlers:
        return
    LOG.setLevel(logging.INFO)
    try:
        handler = RotatingFileHandler(log_path(), maxBytes=1_000_000, backupCount=1,
                                      encoding="utf-8")
    except OSError:
        return
    handler.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-7s %(message)s",
                                           "%Y-%m-%d %H:%M:%S"))
    LOG.addHandler(handler)
    import platform as _platform
    LOG.info("=" * 70)
    LOG.info("%s %s starting", APP_NAME, APP_VERSION)
    LOG.info("Python %s  |  %s", sys.version.split()[0], sys.executable)
    LOG.info("System %s %s", _platform.system(), _platform.release())
    try:
        import PySide6
        LOG.info("PySide6 %s", PySide6.__version__)
    except Exception:           # noqa: BLE001
        pass
    LOG.info("Launcher %s", Path(__file__).resolve())

    def excepthook(kind, value, tb):
        # Under pythonw an error inside a button handler would otherwise go
        # nowhere at all: nothing on screen, nothing in a console.
        LOG.error("Unhandled error:\n%s", "".join(traceback.format_exception(kind, value, tb)))
        _show_error_once(f"{kind.__name__}: {value}")

    def thread_hook(args):
        LOG.error("Unhandled error in thread %s:\n%s", args.thread.name if args.thread else "?",
                  "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)))

    sys.excepthook = excepthook
    threading.excepthook = thread_hook


_last_error_shown = [0.0]


def _show_error_once(summary: str) -> None:
    """Tell the user, but never flood them with a dialog per error."""
    now = time.monotonic()
    if now - _last_error_shown[0] < 5:
        return
    _last_error_shown[0] = now
    try:
        app = QApplication.instance()
        if app is not None:
            QMessageBox.warning(
                None, f"{APP_NAME} - something went wrong",
                f"{summary}\n\nThe details are in the log:\n{log_path()}\n\n"
                f"Settings -> Open log shows it.")
    except Exception:           # noqa: BLE001
        pass


def split_arguments(text: str) -> list[str]:
    """Split the argument field into a list, the same way on every system.

    shlex in POSIX mode eats Windows backslashes (E:\\data -> E:data); in
    Windows mode it keeps the quotes, so a quoted path reached the tool as
    "E:/My Folder" - quotes included - and every tool reported the folder as
    missing. Split in non-POSIX mode (backslashes survive), then take one
    layer of matching quotes off each piece.
    """
    try:
        parts = shlex.split(text, posix=False)
    except ValueError:              # an unclosed quote: fall back to whitespace
        parts = text.split()
    cleaned = []
    for part in parts:
        if len(part) >= 2 and part[0] == part[-1] and part[0] in "\"'":
            part = part[1:-1]
        cleaned.append(part)
    return cleaned


def child_interpreter(executable: str) -> str:
    """The interpreter to run tools with.

    Double-clicked, the launcher runs under pythonw.exe - the variant without
    a console. Tools started with it have no dependable stdout/stderr, so
    their output and error messages can simply vanish. python.exe sitting
    next to it is the same installation with working output; Qt starts it
    without a console window because the launcher itself has none.
    """
    path = Path(executable)
    if path.name.lower() == "pythonw.exe":
        console = path.with_name("python.exe")
        if console.is_file():
            return str(console)
    return executable


class Store:
    """Everything the launcher remembers between sessions."""

    def __init__(self, path: Path):
        self.path = path
        self.data: dict = {
            "folders": [],
            "recursive": True,
            "interpreter": "",
            "sort": "modified",
            "view_mode": "list",
            "favourites": [],
            "stats": {},          # script key -> {"runs": int, "last": float}
            "saved_args": {},     # script key -> str
            "window": {},
            "console_visible": False,
            "confirm_on_run": False,
            "show_schedule": True,
            "hidden_scripts": [],     # keys the user chose to hide from the library
        }
        self.load()

    # -- persistence -------------------------------------------------------
    def load(self) -> None:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                self.data.update(raw)
        except (OSError, ValueError):
            pass

    def save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
            tmp.replace(self.path)
        except OSError:
            pass

    # -- convenience -------------------------------------------------------
    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value) -> None:
        self.data[key] = value
        self.save()

    @property
    def folders(self) -> list[str]:
        return [f for f in self.data.get("folders", []) if f]

    def add_folder(self, folder: str) -> bool:
        folders = self.folders
        resolved = str(Path(folder).resolve())
        if resolved in folders:
            return False
        folders.append(resolved)
        self.data["folders"] = folders
        self.save()
        return True

    def remove_folder(self, folder: str) -> None:
        self.data["folders"] = [f for f in self.folders if f != folder]
        self.save()

    def is_favourite(self, key: str) -> bool:
        return key in self.data.get("favourites", [])

    def toggle_favourite(self, key: str) -> bool:
        favourites = list(self.data.get("favourites", []))
        if key in favourites:
            favourites.remove(key)
            state = False
        else:
            favourites.append(key)
            state = True
        self.data["favourites"] = favourites
        self.save()
        return state

    def stats_for(self, key: str) -> dict:
        return self.data.get("stats", {}).get(key, {"runs": 0, "last": 0.0})

    def record_run(self, key: str) -> None:
        stats = self.data.setdefault("stats", {})
        entry = stats.setdefault(key, {"runs": 0, "last": 0.0})
        entry["runs"] = int(entry.get("runs", 0)) + 1
        entry["last"] = time.time()
        self.save()

    def hide_script(self, key: str) -> None:
        hidden = list(self.data.get("hidden_scripts", []))
        if key not in hidden:
            hidden.append(key)
        self.data["hidden_scripts"] = hidden
        self.save()

    def unhide_all(self) -> None:
        self.data["hidden_scripts"] = []
        self.save()

    def forget_script(self, key: str) -> None:
        """Drop everything remembered about a script that no longer exists."""
        for field in ("favourites",):
            self.data[field] = [k for k in self.data.get(field, []) if k != key]
        for field in ("stats", "saved_args"):
            self.data.get(field, {}).pop(key, None)
        self.data["hidden_scripts"] = [
            k for k in self.data.get("hidden_scripts", []) if k != key
        ]
        self.save()

    def saved_args(self, key: str) -> str:
        return self.data.get("saved_args", {}).get(key, "")

    def set_saved_args(self, key: str, value: str) -> None:
        args = self.data.setdefault("saved_args", {})
        if value:
            args[key] = value
        else:
            args.pop(key, None)
        self.save()


# --------------------------------------------------------------------------
# Script metadata
# --------------------------------------------------------------------------

METADATA_ALIASES = {
    "name": "name",
    "title": "name",
    "category": "category",
    "group": "category",
    "description": "description",
    "summary": "description",
    "author": "author",
    "version": "version",
    "tags": "tags",
    "keywords": "tags",
    "icon": "icon",
    "suite": "suite",
    "suite order": "suite_order",
    "suite role": "suite_role",
    "args": "default_args",
    "arguments": "default_args",
    "requires": "requires",
    "terminal": "terminal",
    "hidden": "hidden",
    "order": "order",
}

KEY_LINE = re.compile(r"^([A-Za-z][A-Za-z _-]{1,20})\s*:\s*(.*)$")
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
MISSING_MODULE_RE = re.compile(r"No module named ['\"]([A-Za-z0-9_.]+)['\"]")

# Import names that differ from the package you install.
MODULE_TO_PACKAGE = {
    "pil": "pillow",
    "cv2": "opencv-python",
    "win32com": "pywin32",
    "pythoncom": "pywin32",
    "yaml": "pyyaml",
    "bs4": "beautifulsoup4",
    "docx": "python-docx",
    "pptx": "python-pptx",
    "fitz": "pymupdf",
    "simple_lama_inpainting": "simple-lama-inpainting",
    "tkinterdnd2": "tkinterdnd2",
    "send2trash": "send2trash",
    "tkinter": "python3-tk (system package, not pip)",
}


def _truthy(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def prettify_filename(stem: str) -> str:
    cleaned = re.sub(r"[_\-.]+", " ", stem).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    if not cleaned:
        return stem
    words = []
    for word in cleaned.split(" "):
        words.append(word if word.isupper() else word[:1].upper() + word[1:])
    return " ".join(words)


@dataclass
class ScriptMeta:
    path: Path
    root: Path
    kind: str
    mtime: float
    size: int
    name: str = ""
    category: str = ""
    description: str = ""
    author: str = ""
    version: str = ""
    tags: list[str] = field(default_factory=list)
    icon: str = ""
    suite: str = ""
    suite_order: int = 0
    suite_role: str = ""
    default_args: str = ""
    requires: str = ""
    terminal: bool = False
    hidden: bool = False
    order: int = 0

    @property
    def key(self) -> str:
        return str(self.path).replace("\\", "/").lower()

    @property
    def relative(self) -> str:
        try:
            return str(self.path.relative_to(self.root))
        except ValueError:
            return self.path.name

    @property
    def badge(self) -> str:
        if self.icon:
            return self.icon[:2]
        letters = [w[0] for w in re.split(r"\s+", self.name) if w]
        return "".join(letters[:2]).upper() or "?"

    @property
    def is_hub(self) -> bool:
        return self.suite_role == "hub"

    def haystack(self) -> str:
        return " ".join(
            [self.name, self.category, self.description, " ".join(self.tags),
             self.path.name, self.author, self.suite]
        ).lower()


def read_header_lines(path: Path, max_lines: int = 90) -> list[str]:
    """Return the comment / docstring header of a script, stripped of markers."""
    out: list[str] = []
    in_docstring = False
    delimiter = ""
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for index, raw in enumerate(handle):
                if index >= max_lines:
                    break
                line = raw.rstrip("\n").rstrip("\r")
                stripped = line.strip()

                if in_docstring:
                    if delimiter in stripped:
                        in_docstring = False
                        stripped = stripped.split(delimiter)[0]
                    out.append(stripped)
                    continue

                if not stripped:
                    out.append("")
                    continue
                if stripped.startswith("#!"):
                    continue
                if stripped.startswith("#") or stripped.startswith("//"):
                    out.append(stripped.lstrip("#/ ").rstrip())
                    continue
                if stripped.startswith("<#"):          # PowerShell block comment
                    out.append(stripped[2:].strip())
                    continue
                if stripped.startswith("::") or stripped.upper().startswith("REM "):
                    out.append(stripped.lstrip(": ").removeprefix("REM ").strip())
                    continue
                for quote in ('"""', "'''"):
                    if stripped.startswith(quote) or stripped.startswith("r" + quote):
                        body = stripped.split(quote, 1)[1]
                        if quote in body:
                            out.append(body.split(quote)[0].strip())
                        else:
                            in_docstring = True
                            delimiter = quote
                            out.append(body.strip())
                        break
                else:
                    # First real statement - the header is over.
                    if stripped.startswith(("import ", "from ")):
                        continue
                    break
    except OSError:
        return out
    return out


def parse_metadata(path: Path, root: Path) -> ScriptMeta:
    """Build a ScriptMeta from a script file, filling in sensible fallbacks."""
    try:
        stat = path.stat()
        mtime, size = stat.st_mtime, stat.st_size
    except OSError:
        mtime, size = 0.0, 0

    meta = ScriptMeta(
        path=path,
        root=root,
        kind=SCRIPT_EXTENSIONS.get(path.suffix.lower(), "python"),
        mtime=mtime,
        size=size,
    )

    lines = read_header_lines(path)
    free_text: list[str] = []
    last_field: str | None = None

    for line in lines:
        match = KEY_LINE.match(line)
        if match:
            raw_key = match.group(1).strip().lower().replace("-", " ").replace("_", " ")
            field_name = METADATA_ALIASES.get(raw_key)
            value = match.group(2).strip()
            if field_name is None:
                last_field = None
                if line and not line.startswith("="):
                    free_text.append(line)
                continue
            last_field = field_name
            if field_name == "tags":
                meta.tags = [t.strip() for t in re.split(r"[,;]", value) if t.strip()]
            elif field_name == "terminal":
                meta.terminal = _truthy(value)
            elif field_name == "hidden":
                meta.hidden = _truthy(value)
            elif field_name in ("order", "suite_order"):
                try:
                    setattr(meta, field_name, int(value))
                except ValueError:
                    setattr(meta, field_name, 0)
            elif field_name == "suite_role":
                meta.suite_role = value.strip().lower()
            else:
                setattr(meta, field_name, value)
            continue

        if not line:
            last_field = None
            continue
        if set(line) <= {"=", "-", "~", "*", "_"}:
            continue
        if last_field == "description" and meta.description:
            meta.description = f"{meta.description} {line}".strip()
        else:
            last_field = None
            free_text.append(line)

    if not meta.name:
        meta.name = prettify_filename(path.stem)
    if not meta.description:
        for candidate in free_text:
            if len(candidate) > 3:
                meta.description = candidate
                break
    if not meta.category:
        try:
            parent = path.parent.relative_to(root)
            meta.category = parent.parts[0] if parent.parts else UNCATEGORISED
        except ValueError:
            meta.category = UNCATEGORISED
        meta.category = prettify_filename(meta.category) if meta.category != UNCATEGORISED else UNCATEGORISED
    meta.description = re.sub(r"\s+", " ", meta.description).strip()
    return meta


class ScriptIndex:
    """Scans the configured folders and keeps the resulting ScriptMeta list."""

    def __init__(self, store: Store):
        self.store = store
        self.scripts: list[ScriptMeta] = []
        self.errors: list[str] = []
        # (path, root) -> (mtime, size, meta). Re-parsing 200 headers on every
        # rescan is wasted work when nothing about the file has changed.
        self._cache: dict[tuple[str, str], tuple[float, int, ScriptMeta]] = {}
        self.self_paths = {
            Path(__file__).resolve(),
            Path(__file__).resolve().parent / "yakshave_assets.py",
        }
        # A copy of the launcher sitting in the scripts folder is still the
        # launcher - opening a second one from inside the first is never what
        # anyone wants, so it is excluded by name as well as by path.
        self.self_names = {"yakshave_launcher.py", "yakshave_assets.py"}

    def scan(self) -> None:
        self.scripts = []
        self.errors = []
        recursive = bool(self.store.get("recursive", True))
        seen: set[Path] = set()

        for folder in self.store.folders:
            root = Path(folder)
            if not root.is_dir():
                self.errors.append(f"Folder not found: {folder}")
                continue
            hidden_keys = {
                key.replace("\\", "/").lower()
                for key in self.store.get("hidden_scripts", [])
            }
            for file_path in self._walk(root, recursive):
                resolved = file_path.resolve()
                if resolved in seen or resolved in self.self_paths:
                    continue
                if file_path.name.lower() in self.self_names:
                    continue
                seen.add(resolved)
                meta = self._meta_for(file_path, root)
                if meta is None or meta.hidden:
                    continue
                if meta.key in hidden_keys:
                    continue
                self.scripts.append(meta)

        self._cache = {
            key: value for key, value in self._cache.items()
            if key[0] in {str(script.path) for script in self.scripts}
        }

    def _meta_for(self, file_path: Path, root: Path) -> ScriptMeta | None:
        try:
            stat = file_path.stat()
        except OSError:
            return None
        key = (str(file_path), str(root))
        cached = self._cache.get(key)
        if cached and cached[0] == stat.st_mtime and cached[1] == stat.st_size:
            return cached[2]
        meta = parse_metadata(file_path, root)
        self._cache[key] = (stat.st_mtime, stat.st_size, meta)
        return meta

    def _walk(self, root: Path, recursive: bool):
        stack = [root]
        while stack:
            current = stack.pop()
            try:
                entries = list(os.scandir(current))
            except OSError:
                self.errors.append(f"Cannot read: {current}")
                continue
            for entry in entries:
                try:
                    if entry.is_dir(follow_symlinks=False):
                        if not recursive:
                            continue
                        name = entry.name
                        if name in IGNORED_DIR_NAMES or name.startswith("."):
                            continue
                        stack.append(Path(entry.path))
                    elif entry.is_file(follow_symlinks=False):
                        suffix = Path(entry.name).suffix.lower()
                        if suffix in SCRIPT_EXTENSIONS and not entry.name.startswith("."):
                            yield Path(entry.path)
                except OSError:
                    continue

    def suites(self) -> list[tuple[str, int]]:
        """Suite name -> how many scripts belong to it, by their own header."""
        counts: dict[str, int] = {}
        for script in self.scripts:
            if script.suite:
                counts[script.suite] = counts.get(script.suite, 0) + 1
        return sorted(counts.items(), key=lambda item: item[0].lower())

    def categories(self) -> list[tuple[str, int]]:
        counts: dict[str, int] = {}
        for script in self.scripts:
            counts[script.category] = counts.get(script.category, 0) + 1
        return sorted(counts.items(), key=lambda item: item[0].lower())

    def watch_paths(self) -> list[str]:
        paths: set[str] = set()
        recursive = bool(self.store.get("recursive", True))
        for folder in self.store.folders:
            root = Path(folder)
            if not root.is_dir():
                continue
            paths.add(str(root))
            if recursive:
                for script in self.scripts:
                    paths.add(str(script.path.parent))
        return sorted(paths)


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

def human_time(timestamp: float) -> str:
    if not timestamp:
        return "never"
    delta = time.time() - timestamp
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{int(delta // 60)} min ago"
    if delta < 86400:
        return f"{int(delta // 3600)} h ago"
    if delta < 7 * 86400:
        return f"{int(delta // 86400)} d ago"
    return time.strftime("%d %b %Y", time.localtime(timestamp))


def human_size(size: int) -> str:
    if size < 1024:
        return f"{size} B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size / (1024 * 1024):.1f} MB"


def load_logo_pixmap(size: int = 96) -> QPixmap | None:
    """Load the Yak Shave mark, from the embedded asset or a neighbouring file."""
    data = None
    try:
        from yakshave_assets import logo_bytes  # type: ignore
        data = logo_bytes()
    except Exception:
        for candidate in ("yakshave_logo.png", "logo.png", "yakshave.png"):
            file_path = Path(__file__).resolve().parent / candidate
            if file_path.exists():
                try:
                    data = file_path.read_bytes()
                    break
                except OSError:
                    continue
    if not data:
        return None
    pixmap = QPixmap()
    if not pixmap.loadFromData(data):
        return None
    return pixmap.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)


def rounded_pixmap(source: QPixmap, size: int, radius: int | None = None) -> QPixmap:
    """Round the corners of a pixmap (radius=None gives a circle)."""
    scaled = source.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    result = QPixmap(size, size)
    result.fill(Qt.transparent)
    painter = QPainter(result)
    painter.setRenderHint(QPainter.Antialiasing, True)
    path = QPainterPath()
    path.addRoundedRect(0, 0, size, size, size / 2 if radius is None else radius,
                        size / 2 if radius is None else radius)
    painter.setClipPath(path)
    painter.drawPixmap(0, 0, scaled)
    painter.end()
    return result


def star_icon(filled: bool, size: int = 20) -> QIcon:
    """Draw a five-point star so we never depend on a font shipping one."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing, True)
    path = QPainterPath()
    centre = size / 2
    outer, inner = size * 0.46, size * 0.20
    for step in range(10):
        angle = -math.pi / 2 + step * math.pi / 5
        radius = outer if step % 2 == 0 else inner
        x = centre + radius * math.cos(angle)
        y = centre + radius * math.sin(angle)
        if step == 0:
            path.moveTo(x, y)
        else:
            path.lineTo(x, y)
    path.closeSubpath()
    if filled:
        painter.fillPath(path, QColor(Theme.ACCENT))
    else:
        pen = QPen(QColor(Theme.TEXT_MUTED))
        pen.setWidthF(1.4)
        painter.setPen(pen)
        painter.drawPath(path)
    painter.end()
    return QIcon(pixmap)


def close_icon(size: int = 14) -> QIcon:
    """A small cross for the console tabs."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing, True)
    pen = QPen(QColor(Theme.TEXT_MUTED))
    pen.setWidthF(1.5)
    pen.setCapStyle(Qt.RoundCap)
    painter.setPen(pen)
    margin = size * 0.28
    painter.drawLine(margin, margin, size - margin, size - margin)
    painter.drawLine(size - margin, margin, margin, size - margin)
    painter.end()
    return QIcon(pixmap)


class ElidedLabel(QLabel):
    """A single-line label that shortens its text with an ellipsis when needed."""

    def __init__(self, text: str = "", parent=None):
        super().__init__(text, parent)
        self._full_text = text
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)

    def setText(self, text: str) -> None:  # noqa: N802 - Qt naming
        self._full_text = text
        super().setText(text)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        metrics = painter.fontMetrics()
        elided = metrics.elidedText(self._full_text, Qt.ElideRight, self.width())
        painter.setPen(self.palette().color(self.foregroundRole()))
        painter.drawText(self.rect(), int(self.alignment()) | int(Qt.AlignVCenter), elided)
        painter.end()

    def minimumSizeHint(self) -> QSize:
        hint = super().minimumSizeHint()
        return QSize(40, hint.height())


# --------------------------------------------------------------------------
# Script card
# --------------------------------------------------------------------------

class ScriptCard(QFrame):
    """One script, rendered as a clickable card."""

    activated = Signal(object)          # double click / Run button -> ScriptMeta
    selected = Signal(object)
    favourite_toggled = Signal(object)
    context_requested = Signal(object, QPoint)

    def __init__(self, meta: ScriptMeta, store: Store, compact: bool = False, parent=None):
        super().__init__(parent)
        self.meta = meta
        self.store = store
        self.compact = compact
        self._selected = False
        self.setObjectName("ScriptCard")
        self.setProperty("selected", False)
        self.setCursor(Qt.PointingHandCursor)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._on_context_menu)

        layout = QHBoxLayout(self)
        if compact:
            layout.setContentsMargins(12, 7, 10, 7)
            layout.setSpacing(12)
        else:
            layout.setContentsMargins(14, 12, 12, 12)
            layout.setSpacing(14)

        badge_size = 28 if compact else 40
        self.badge = QLabel(meta.badge)
        self.badge.setObjectName("CardBadgeSmall" if compact else "CardBadge")
        self.badge.setAlignment(Qt.AlignCenter)
        self.badge.setFixedSize(badge_size, badge_size)
        layout.addWidget(self.badge, 0, Qt.AlignVCenter if compact else Qt.AlignTop)

        if compact:
            self._build_compact(layout)
        else:
            self._build_full(layout)

        actions = QHBoxLayout()
        actions.setSpacing(6)
        self.star = QToolButton()
        self.star.setObjectName("StarButton")
        self.star.setCheckable(True)
        self.star.setChecked(store.is_favourite(meta.key))
        self.star.setIcon(star_icon(self.star.isChecked()))
        self.star.setIconSize(QSize(17, 17))
        self.star.setFixedSize(30, 30)
        self.star.setToolTip("Favourite")
        self.star.setCursor(Qt.PointingHandCursor)
        self.star.clicked.connect(self._on_star)
        actions.addWidget(self.star, 0, Qt.AlignVCenter)

        self.run_button = QPushButton("Run")
        self.run_button.setObjectName("CardRunButton")
        self.run_button.setCursor(Qt.PointingHandCursor)
        self.run_button.clicked.connect(lambda _checked=False: self.activated.emit(self.meta))
        actions.addWidget(self.run_button, 0, Qt.AlignVCenter)

        layout.addLayout(actions, 0)

    # -- layouts -----------------------------------------------------------
    def _title_widgets(self) -> list[QWidget]:
        widgets: list[QWidget] = []
        title = QLabel(self.meta.name)
        title.setObjectName("CardTitle")
        widgets.append(title)

        kind_chip = QLabel(KIND_LABELS.get(self.meta.kind, "?"))
        kind_chip.setObjectName("KindChip")
        widgets.append(kind_chip)

        if self.meta.is_hub:
            hub_chip = QLabel("HUB")
            hub_chip.setObjectName("HubChip")
            hub_chip.setToolTip("Runs the other tools of this suite together.")
            widgets.append(hub_chip)

        if self.meta.version:
            version_chip = QLabel(f"v{self.meta.version}")
            version_chip.setObjectName("MetaChip")
            widgets.append(version_chip)
        return widgets

    def _build_full(self, layout: QHBoxLayout) -> None:
        column = QVBoxLayout()
        column.setSpacing(4)
        column.setContentsMargins(0, 0, 0, 0)

        title_row = QHBoxLayout()
        title_row.setSpacing(8)
        for widget in self._title_widgets():
            title_row.addWidget(widget, 0)
        title_row.addStretch(1)
        column.addLayout(title_row)

        text = self.meta.description or "No description in this script's header."
        if len(text) > 200:
            text = text[:197].rstrip() + "..."
        description = QLabel(text)
        description.setObjectName(
            "CardDescription" if self.meta.description else "CardDescriptionEmpty"
        )
        description.setWordWrap(True)
        description.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        column.addWidget(description)

        footer = QHBoxLayout()
        footer.setSpacing(10)
        category_chip = QLabel(self.meta.category)
        category_chip.setObjectName("CategoryChip")
        footer.addWidget(category_chip, 0)
        if self.meta.suite:
            suite_chip = QLabel(f"{self.meta.suite} suite")
            suite_chip.setObjectName("SuiteChip")
            footer.addWidget(suite_chip, 0)
        footer.addWidget(self._stats_label(), 0)
        footer.addStretch(1)
        column.addLayout(footer)

        layout.addLayout(column, 1)

    def _build_compact(self, layout: QHBoxLayout) -> None:
        row = QHBoxLayout()
        row.setSpacing(8)
        row.setContentsMargins(0, 0, 0, 0)
        for widget in self._title_widgets():
            row.addWidget(widget, 0)
        row.addSpacing(4)

        if self.meta.description:
            description = ElidedLabel(self.meta.description)
            description.setObjectName("CardDescription")
            row.addWidget(description, 1)
        else:
            row.addStretch(1)

        if self.meta.suite:
            suite_chip = QLabel(f"{self.meta.suite} suite")
            suite_chip.setObjectName("SuiteChip")
            row.addWidget(suite_chip, 0)
        category_chip = QLabel(self.meta.category)
        category_chip.setObjectName("CategoryChip")
        row.addWidget(category_chip, 0)
        layout.addLayout(row, 1)

    def _stats_label(self) -> QLabel:
        stats = self.store.stats_for(self.meta.key)
        bits = [f"modified {human_time(self.meta.mtime)}"]
        if stats.get("runs"):
            plural = "s" if stats["runs"] != 1 else ""
            bits.append(f"{stats['runs']} run{plural}")
            bits.append(f"last {human_time(stats.get('last', 0))}")
        label = QLabel("  \u00b7  ".join(bits))
        label.setObjectName("CardFooter")
        return label

    # -- interaction -------------------------------------------------------
    def _on_star(self, _checked: bool = False) -> None:
        self.star.setIcon(star_icon(self.star.isChecked()))
        self.favourite_toggled.emit(self.meta)

    def _on_context_menu(self, position: QPoint) -> None:
        self.context_requested.emit(self.meta, self.mapToGlobal(position))

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.selected.emit(self.meta)
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.activated.emit(self.meta)
        super().mouseDoubleClickEvent(event)

    def set_selected(self, state: bool) -> None:
        if state == self._selected:
            return
        self._selected = state
        self.setProperty("selected", state)
        self.style().unpolish(self)
        self.style().polish(self)


# --------------------------------------------------------------------------
# Sidebar
# --------------------------------------------------------------------------

class NavRow(QFrame):
    """A sidebar row: label on the left, count on the right."""

    clicked = Signal(str)

    def __init__(self, key: str, label: str, parent=None):
        super().__init__(parent)
        self.key = key
        self.setObjectName("NavRow")
        self.setProperty("active", False)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(34)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 0, 12, 0)
        layout.setSpacing(8)

        self.label = QLabel(label)
        self.label.setObjectName("NavRowLabel")
        layout.addWidget(self.label, 1)

        self.count = QLabel("")
        self.count.setObjectName("NavRowCount")
        layout.addWidget(self.count, 0)

    def set_count(self, value: int) -> None:
        self.count.setText(str(value))

    def set_active(self, state: bool) -> None:
        self.setProperty("active", state)
        self.label.setProperty("active", state)
        for widget in (self, self.label, self.count):
            widget.style().unpolish(widget)
            widget.style().polish(widget)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self.key)
        super().mousePressEvent(event)


class Sidebar(QWidget):
    """Library shortcuts and the category list."""

    view_changed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self.setFixedWidth(236)
        self._current = VIEW_ALL
        self.rows: dict[str, NavRow] = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 14, 10, 10)
        layout.setSpacing(2)

        layout.addWidget(self._section_label("LIBRARY"))
        for key, label in (
            (VIEW_ALL, "All scripts"),
            (VIEW_FAVOURITES, "Favourites"),
            (VIEW_RECENT, "Recently run"),
            (VIEW_SCHEDULE, "Release schedule"),
        ):
            row = NavRow(key, label)
            row.clicked.connect(self._on_row_clicked)
            self.rows[key] = row
            layout.addWidget(row)
        self.rows[VIEW_SCHEDULE].setVisible(False)      # only when a schedule file exists

        layout.addSpacing(12)
        self.suites_label = self._section_label("SUITES")
        layout.addWidget(self.suites_label)

        self.suite_container = QWidget()
        self.suite_container.setObjectName("SuiteContainer")
        self.suite_layout = QVBoxLayout(self.suite_container)
        self.suite_layout.setContentsMargins(0, 0, 0, 0)
        self.suite_layout.setSpacing(2)
        layout.addWidget(self.suite_container)

        layout.addSpacing(12)
        layout.addWidget(self._section_label("CATEGORIES"))

        self.category_scroll = QScrollArea()
        self.category_scroll.setObjectName("CategoryScroll")
        self.category_scroll.setWidgetResizable(True)
        self.category_scroll.setFrameShape(QFrame.NoFrame)
        self.category_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.category_container = QWidget()
        self.category_container.setObjectName("CategoryContainer")
        self.category_layout = QVBoxLayout(self.category_container)
        self.category_layout.setContentsMargins(0, 0, 0, 0)
        self.category_layout.setSpacing(2)
        self.category_layout.addStretch(1)
        self.category_scroll.setWidget(self.category_container)
        layout.addWidget(self.category_scroll, 1)

        separator = QFrame()
        separator.setObjectName("Divider")
        separator.setFixedHeight(1)
        layout.addSpacing(6)
        layout.addWidget(separator)

        self.footer = QLabel(f"{APP_NAME} {APP_VERSION}")
        self.footer.setObjectName("SidebarFooter")
        layout.addWidget(self.footer)

        self.set_current(VIEW_ALL)

    def _section_label(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("SectionLabel")
        return label

    def _on_row_clicked(self, key: str) -> None:
        self.set_current(key, emit=True)

    def set_counts(self, total: int, favourites: int, recent: int,
                   categories: list[tuple[str, int]],
                   suites: list[tuple[str, int]] | None = None) -> None:
        self.rows[VIEW_ALL].set_count(total)
        self.rows[VIEW_FAVOURITES].set_count(favourites)
        self.rows[VIEW_RECENT].set_count(recent)

        for key in list(self.rows):
            if key in (VIEW_ALL, VIEW_FAVOURITES, VIEW_RECENT, VIEW_SCHEDULE):
                continue
            row = self.rows.pop(key)
            row.setParent(None)
            row.deleteLater()

        # Suites come from the scripts' own Suite: header, so a new suite
        # shows up here without the launcher ever being changed again.
        suites = suites or []
        self.suites_label.setVisible(bool(suites))
        self.suite_container.setVisible(bool(suites))
        for name, count in suites:
            row = NavRow(f"{SUITE_PREFIX}{name}", name)
            row.set_count(count)
            row.clicked.connect(self._on_row_clicked)
            self.rows[f"{SUITE_PREFIX}{name}"] = row
            self.suite_layout.addWidget(row)

        for name, count in categories:
            row = NavRow(name, name)
            row.set_count(count)
            row.clicked.connect(self._on_row_clicked)
            self.rows[name] = row
            self.category_layout.insertWidget(self.category_layout.count() - 1, row)

        self._apply_active()

    def _apply_active(self) -> None:
        for key, row in self.rows.items():
            row.set_active(key == self._current)

    def set_current(self, key: str, emit: bool = False) -> None:
        self._current = key
        self._apply_active()
        if emit:
            self.view_changed.emit(key)


# --------------------------------------------------------------------------
# Detail panel
# --------------------------------------------------------------------------

class DetailPanel(QWidget):
    """Everything about the selected script, plus the run controls."""

    run_requested = Signal(object, str, bool)     # meta, args, in_terminal
    help_requested = Signal(object)
    reveal_requested = Signal(object)
    edit_requested = Signal(object)

    def __init__(self, store: Store, parent=None):
        super().__init__(parent)
        self.store = store
        self.meta: ScriptMeta | None = None
        self.setObjectName("DetailPanel")
        self.setFixedWidth(340)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setObjectName("DetailScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        outer.addWidget(scroll, 1)

        container = QWidget()
        container.setObjectName("DetailContainer")
        scroll.setWidget(container)

        layout = QVBoxLayout(container)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        self.empty_label = QLabel(
            "Select a script to see its details.\n\n"
            "Double-click a card to run it straight away."
        )
        self.empty_label.setObjectName("DetailEmpty")
        self.empty_label.setWordWrap(True)
        self.empty_label.setAlignment(Qt.AlignTop)
        layout.addWidget(self.empty_label)

        self.body = QWidget()
        self.body.setObjectName("DetailBody")
        body_layout = QVBoxLayout(self.body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(12)

        self.title = QLabel()
        self.title.setObjectName("DetailTitle")
        self.title.setWordWrap(True)
        body_layout.addWidget(self.title)

        self.subtitle = QLabel()
        self.subtitle.setObjectName("DetailSubtitle")
        self.subtitle.setWordWrap(True)
        body_layout.addWidget(self.subtitle)

        self.description = QLabel()
        self.description.setObjectName("DetailDescription")
        self.description.setWordWrap(True)
        body_layout.addWidget(self.description)

        self.tags_label = QLabel()
        self.tags_label.setObjectName("DetailTags")
        self.tags_label.setWordWrap(True)
        body_layout.addWidget(self.tags_label)

        divider = QFrame()
        divider.setObjectName("Divider")
        divider.setFixedHeight(1)
        body_layout.addWidget(divider)

        self.facts = QLabel()
        self.facts.setObjectName("DetailFacts")
        self.facts.setWordWrap(True)
        self.facts.setTextInteractionFlags(Qt.TextSelectableByMouse)
        body_layout.addWidget(self.facts)

        args_label = QLabel("ARGUMENTS")
        args_label.setObjectName("SectionLabel")
        body_layout.addWidget(args_label)

        self.args_input = QLineEdit()
        self.args_input.setObjectName("ArgsInput")
        self.args_input.setPlaceholderText("Leave empty, or add options - see Show help")
        self.args_input.returnPressed.connect(self._on_run)
        self.args_input.editingFinished.connect(self._store_args)
        body_layout.addWidget(self.args_input)

        insert_row = QHBoxLayout()
        insert_row.setSpacing(8)
        self.folder_button = QPushButton("Insert folder...")
        self.folder_button.setObjectName("GhostButton")
        self.folder_button.setCursor(Qt.PointingHandCursor)
        self.folder_button.setToolTip(
            "Pick a folder and paste its path into the arguments above."
        )
        self.folder_button.clicked.connect(lambda _checked=False: self._insert_path(folder=True))
        insert_row.addWidget(self.folder_button)

        self.file_button = QPushButton("Insert file...")
        self.file_button.setObjectName("GhostButton")
        self.file_button.setCursor(Qt.PointingHandCursor)
        self.file_button.setToolTip(
            "Pick a file and paste its path into the arguments above."
        )
        self.file_button.clicked.connect(lambda _checked=False: self._insert_path(folder=False))
        insert_row.addWidget(self.file_button)
        body_layout.addLayout(insert_row)

        self.args_hint = QLabel(
            "Most tools need a folder or file to work on. Pick one with the buttons, "
            "then press Run. \"Show help\" lists everything this tool accepts."
        )
        self.args_hint.setObjectName("HintLabel")
        self.args_hint.setWordWrap(True)
        body_layout.addWidget(self.args_hint)

        self.terminal_check = QCheckBox("Run in an external terminal window")
        self.terminal_check.setObjectName("TerminalCheck")
        self.terminal_check.setToolTip(
            "Use this for interactive command-line tools that expect a real console."
        )
        body_layout.addWidget(self.terminal_check)

        self.run_button = QPushButton("Run script")
        self.run_button.setObjectName("PrimaryButton")
        self.run_button.setCursor(Qt.PointingHandCursor)
        self.run_button.clicked.connect(lambda _checked=False: self._on_run())
        body_layout.addWidget(self.run_button)

        self.help_button = QPushButton("Show help")
        self.help_button.setObjectName("GhostButton")
        self.help_button.setCursor(Qt.PointingHandCursor)
        self.help_button.setToolTip(
            "Run this tool with --help and show what it accepts, without doing anything else."
        )
        self.help_button.clicked.connect(lambda _checked=False: self._on_help())
        body_layout.addWidget(self.help_button)

        button_row = QHBoxLayout()
        button_row.setSpacing(8)
        self.reveal_button = QPushButton("Show in folder")
        self.reveal_button.setObjectName("GhostButton")
        self.reveal_button.setCursor(Qt.PointingHandCursor)
        self.reveal_button.clicked.connect(
            lambda _checked=False: self.meta and self.reveal_requested.emit(self.meta)
        )
        button_row.addWidget(self.reveal_button)

        self.edit_button = QPushButton("Open file")
        self.edit_button.setObjectName("GhostButton")
        self.edit_button.setCursor(Qt.PointingHandCursor)
        self.edit_button.clicked.connect(
            lambda _checked=False: self.meta and self.edit_requested.emit(self.meta)
        )
        button_row.addWidget(self.edit_button)
        body_layout.addLayout(button_row)

        body_layout.addStretch(1)
        layout.addWidget(self.body, 1)
        self.body.setVisible(False)

    def _store_args(self) -> None:
        if self.meta:
            self.store.set_saved_args(self.meta.key, self.args_input.text().strip())

    def _insert_path(self, folder: bool) -> None:
        """Let the user pick a path instead of typing it, quoted if needed."""
        if folder:
            chosen = QFileDialog.getExistingDirectory(self, "Pick a folder")
        else:
            chosen, _filter = QFileDialog.getOpenFileName(self, "Pick a file")
        if not chosen:
            return
        quoted = f'"{chosen}"' if " " in chosen else chosen
        current = self.args_input.text().strip()
        self.args_input.setText(f"{current} {quoted}".strip())
        self._store_args()

    def _on_help(self) -> None:
        if self.meta:
            self.help_requested.emit(self.meta)

    def _on_run(self) -> None:
        if not self.meta:
            return
        self._store_args()
        self.run_requested.emit(
            self.meta, self.args_input.text().strip(), self.terminal_check.isChecked()
        )

    def show_script(self, meta: ScriptMeta | None) -> None:
        self.meta = meta
        self.empty_label.setVisible(meta is None)
        self.body.setVisible(meta is not None)
        if meta is None:
            return

        self.title.setText(meta.name)
        subtitle_bits = [meta.category]
        if meta.version:
            subtitle_bits.append(f"v{meta.version}")
        if meta.author:
            subtitle_bits.append(meta.author)
        self.subtitle.setText("  ·  ".join(subtitle_bits))

        self.description.setText(
            meta.description or "This script has no Description field in its header."
        )
        self.tags_label.setText("  ".join(f"#{tag}" for tag in meta.tags))
        self.tags_label.setVisible(bool(meta.tags))

        stats = self.store.stats_for(meta.key)
        facts = [
            f"File          {meta.relative}",
            f"Type          {KIND_LABELS.get(meta.kind, meta.kind)}  ·  {human_size(meta.size)}",
            f"Modified      {human_time(meta.mtime)}",
            f"Runs          {stats.get('runs', 0)}  ·  last {human_time(stats.get('last', 0))}",
        ]
        if meta.suite:
            role = "hub - runs the whole suite" if meta.is_hub else "part of the suite"
            facts.append(f"Suite         {meta.suite}  ({role})")
        if meta.requires:
            facts.append(f"Requires      {meta.requires}")
        self.facts.setText("\n".join(facts))

        saved = self.store.saved_args(meta.key)
        self.args_input.setText(saved or meta.default_args)
        self.terminal_check.setChecked(meta.terminal)


# --------------------------------------------------------------------------
# Console
# --------------------------------------------------------------------------

class RunTab(QWidget):
    """A single running (or finished) script, with live output and stdin."""

    finished = Signal(object)
    title_changed = Signal(object, str)

    def __init__(self, meta: ScriptMeta, command: list[str], workdir: Path, parent=None):
        super().__init__(parent)
        self.meta = meta
        self.command = command
        self.workdir = workdir
        self.started_at = time.time()
        self.setObjectName("RunTab")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 12)
        layout.setSpacing(8)

        header = QHBoxLayout()
        header.setSpacing(10)
        self.status_label = QLabel("Running")
        self.status_label.setObjectName("RunStatusRunning")
        header.addWidget(self.status_label)

        self.command_label = QLabel(" ".join(command))
        self.command_label.setObjectName("RunCommand")
        self.command_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        header.addWidget(self.command_label, 1)

        self.stop_button = QPushButton("Stop")
        self.stop_button.setObjectName("GhostButton")
        self.stop_button.setCursor(Qt.PointingHandCursor)
        self.stop_button.clicked.connect(lambda _checked=False: self.stop())
        header.addWidget(self.stop_button, 0)

        self.clear_button = QPushButton("Clear")
        self.clear_button.setObjectName("GhostButton")
        self.clear_button.setCursor(Qt.PointingHandCursor)
        self.clear_button.clicked.connect(lambda _checked=False: self.output.clear())
        header.addWidget(self.clear_button, 0)
        layout.addLayout(header)

        self.output = QPlainTextEdit()
        self.output.setObjectName("ConsoleOutput")
        self.output.setReadOnly(True)
        self.output.setFont(mono_font(10))
        self.output.setMaximumBlockCount(6000)
        layout.addWidget(self.output, 1)

        input_row = QHBoxLayout()
        input_row.setSpacing(8)
        stdin_label = QLabel("Reply:")
        stdin_label.setObjectName("StdinLabel")
        stdin_label.setToolTip(
            "Some tools ask a question while they run. Answer it here."
        )
        input_row.addWidget(stdin_label, 0)

        self.stdin_input = QLineEdit()
        self.stdin_input.setObjectName("StdinInput")
        self.stdin_input.setPlaceholderText(
            "Only needed if the script asks you something - type the answer and press Enter"
        )
        self.stdin_input.setFont(mono_font(10))
        self.stdin_input.returnPressed.connect(self._send_stdin)
        input_row.addWidget(self.stdin_input, 1)
        layout.addLayout(input_row)

        self.process = QProcess(self)
        self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.setWorkingDirectory(str(workdir))
        # Unbuffered so output arrives live; UTF-8 so a name with an umlaut
        # or a character like "->" can't crash a tool that prints it (the
        # Windows default code page for pipes can't encode everything).
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONUNBUFFERED", "1")
        env.insert("PYTHONIOENCODING", "utf-8")
        self.process.setProcessEnvironment(env)
        self._output_tail: list[str] = []
        self.process.readyReadStandardOutput.connect(self._read_output)
        self.process.finished.connect(self._on_finished)
        self.process.errorOccurred.connect(self._on_error)

        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._tick)
        self._hinted = False

    def start(self) -> None:
        self._append(f"> {' '.join(self.command)}\n", Theme.TEXT_MUTED)
        self._append(f"  in {self.workdir}\n\n", Theme.TEXT_MUTED)
        LOG.info("RUN   %s", self.meta.name)
        LOG.info("      program: %s", self.command[0])
        LOG.info("      args:    %s", self.command[1:])
        LOG.info("      in:      %s", self.workdir)
        self.process.start(self.command[0], self.command[1:])
        self.timer.start()

    def _tick(self) -> None:
        elapsed = int(time.time() - self.started_at)
        self.status_label.setText(f"Running   {elapsed // 60:02d}:{elapsed % 60:02d}")

    def _append(self, text: str, colour: str | None = None) -> None:
        cursor = self.output.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        if colour:
            cursor.insertHtml(
                f'<span style="color:{colour}; white-space:pre-wrap;">'
                f"{self._escape(text)}</span>"
            )
        else:
            cursor.insertText(text)
        self.output.setTextCursor(cursor)
        self.output.ensureCursorVisible()

    @staticmethod
    def _escape(text: str) -> str:
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br>")
            .replace(" ", "&nbsp;")
        )

    def _read_output(self) -> None:
        data = bytes(self.process.readAllStandardOutput())
        text = ANSI_RE.sub("", data.decode("utf-8", errors="replace"))
        self._append(text)
        self._output_tail.extend(text.splitlines())
        del self._output_tail[:-60]
        self._explain_missing_module(text)

    def _explain_missing_module(self, text: str) -> None:
        """A raw ModuleNotFoundError tells you nothing useful on its own."""
        if self._hinted:
            return
        match = MISSING_MODULE_RE.search(text)
        if not match:
            return
        self._hinted = True
        package = MODULE_TO_PACKAGE.get(match.group(1).lower(), match.group(1))
        self._append(
            f"\nThis tool needs a package that is not installed.\n"
            f"Install it with:    pip install {package}\n",
            Theme.WARN,
        )

    def _send_stdin(self) -> None:
        if self.process.state() != QProcess.Running:
            return
        text = self.stdin_input.text()
        self.stdin_input.clear()
        self._append(f"{text}\n", Theme.ACCENT)
        self.process.write((text + "\n").encode("utf-8"))

    def stop(self) -> None:
        if self.process.state() == QProcess.NotRunning:
            return
        self.process.terminate()
        QTimer.singleShot(2500, self._force_kill)

    def _force_kill(self) -> None:
        if self.process.state() != QProcess.NotRunning:
            self.process.kill()

    def _on_error(self, error) -> None:
        LOG.error("      process error: %s (%s)  program=%s",
                  error, self.process.errorString(), self.command[0])
        if error == QProcess.FailedToStart:
            self.timer.stop()
            self._append(
                f"\nCould not start this script: {self.process.errorString()}\n"
                f"Program: {self.command[0]}\n"
                "Check the Python interpreter in Settings.\n",
                Theme.ERROR,
            )
            self.status_label.setText("Failed")
            self.status_label.setObjectName("RunStatusFailed")
            self._restyle()

    def _on_finished(self, exit_code: int, _status) -> None:
        self.timer.stop()
        self.stdin_input.setEnabled(False)
        self.stop_button.setEnabled(False)
        elapsed = time.time() - self.started_at
        if exit_code == 0:
            LOG.info("DONE  %s  exit 0 after %.1fs", self.meta.name, elapsed)
        else:
            LOG.warning("FAIL  %s  exit %s after %.1fs - last output:", self.meta.name, exit_code, elapsed)
            for line in self._output_tail[-40:]:
                LOG.warning("      | %s", line)
        if exit_code == 0:
            self._append(f"\n[finished in {elapsed:.1f}s]\n", Theme.OK)
            self.status_label.setText("Finished")
            self.status_label.setObjectName("RunStatusDone")
        else:
            self._append(f"\n[exit code {exit_code} after {elapsed:.1f}s]\n", Theme.ERROR)
            self.status_label.setText(f"Exit {exit_code}")
            self.status_label.setObjectName("RunStatusFailed")
        self._restyle()
        self.finished.emit(self)

    def _restyle(self) -> None:
        self.status_label.style().unpolish(self.status_label)
        self.status_label.style().polish(self.status_label)

    def is_running(self) -> bool:
        return self.process.state() != QProcess.NotRunning


class ConsoleDock(QWidget):
    """Tabbed container for all running scripts."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ConsoleDock")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("ConsoleTabs")
        self.tabs.setTabsClosable(False)
        self.tabs.setDocumentMode(True)
        self.tabs.tabCloseRequested.connect(self._close_tab)
        layout.addWidget(self.tabs)

        self.placeholder = QLabel(
            "Console\n\nOutput from running scripts appears here.\n"
            "Each run gets its own tab, and several can run at once."
        )
        self.placeholder.setObjectName("ConsolePlaceholder")
        self.placeholder.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.placeholder, 1)
        self.tabs.setVisible(False)

    def add_run(self, tab: RunTab, title: str) -> None:
        index = self.tabs.addTab(tab, title)
        close_button = QToolButton()
        close_button.setObjectName("TabCloseButton")
        close_button.setIcon(close_icon())
        close_button.setIconSize(QSize(12, 12))
        close_button.setCursor(Qt.PointingHandCursor)
        close_button.setToolTip("Close this run")
        close_button.clicked.connect(
            lambda _checked=False, widget=tab: self._close_widget(widget)
        )
        self.tabs.tabBar().setTabButton(index, QTabBar.RightSide, close_button)
        self.tabs.setCurrentIndex(index)
        self.tabs.setVisible(True)
        self.placeholder.setVisible(False)
        tab.finished.connect(self._on_tab_finished)

    def _on_tab_finished(self, tab: RunTab) -> None:
        index = self.tabs.indexOf(tab)
        if index >= 0:
            title = self.tabs.tabText(index).lstrip("• ")
            self.tabs.setTabText(index, title)

    def _close_widget(self, widget: QWidget) -> None:
        index = self.tabs.indexOf(widget)
        if index >= 0:
            self._close_tab(index)

    def _close_tab(self, index: int) -> None:
        widget = self.tabs.widget(index)
        if isinstance(widget, RunTab) and widget.is_running():
            answer = QMessageBox.question(
                self,
                "Script still running",
                f"'{widget.meta.name}' is still running. Stop it and close this tab?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return
            widget.stop()
        self.tabs.removeTab(index)
        if widget is not None:
            widget.deleteLater()
        if self.tabs.count() == 0:
            self.tabs.setVisible(False)
            self.placeholder.setVisible(True)

    def running_count(self) -> int:
        return sum(
            1
            for index in range(self.tabs.count())
            if isinstance(self.tabs.widget(index), RunTab)
            and self.tabs.widget(index).is_running()
        )

    def stop_all(self) -> None:
        for index in range(self.tabs.count()):
            widget = self.tabs.widget(index)
            if isinstance(widget, RunTab) and widget.is_running():
                widget.stop()


# --------------------------------------------------------------------------
# Release schedule - an image file you can drop into your scripts folder.
# The newest one found is shown from the sidebar; a newer file replaces it.
# --------------------------------------------------------------------------

def find_schedule(folders: list[str]) -> Optional[Path]:
    """Newest yakshave_schedule_MM.YYYY.png directly inside any scripts folder.

    Ordered by the month in the name, not by file date, so re-downloading an
    old schedule can never push the current one aside."""
    best: tuple = ()
    found: Optional[Path] = None
    for folder in folders:
        try:
            candidates = list(Path(folder).glob("*.png"))
        except OSError:
            continue
        for path in candidates:
            name = path.stem.lower()
            if not name.startswith(SCHEDULE_PREFIX):
                continue
            match = re.search(r"(\d{2})\.(\d{4})", name)
            key = (int(match.group(2)), int(match.group(1))) if match else (0, 0)
            key = key + (path.stat().st_mtime,)
            if not best or key > best:
                best, found = key, path
    return found


class ScheduleDialog(QDialog):
    """The release schedule, scaled to fit the screen."""

    def __init__(self, image_path: Path, store: "Store", parent=None):
        super().__init__(parent)
        self.store = store
        self.hidden = False
        self.setWindowTitle(f"{APP_NAME} - release schedule")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 12)
        layout.setSpacing(10)

        picture = QLabel()
        picture.setAlignment(Qt.AlignCenter)
        pixmap = QPixmap(str(image_path))
        screen = QApplication.primaryScreen().availableGeometry()
        box = QSize(int(screen.width() * 0.8), int(screen.height() * 0.78))
        if not pixmap.isNull():
            picture.setPixmap(pixmap.scaled(box, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            picture.setText(f"Could not read {image_path.name}")
        layout.addWidget(picture, 1)

        row = QHBoxLayout()
        hide = QPushButton("Don't show the schedule")
        hide.setObjectName("GhostButton")
        hide.setToolTip("Removes the Schedule entry from the sidebar. Settings brings it back.")
        hide.clicked.connect(lambda _checked=False: self._hide())
        row.addWidget(hide)
        row.addStretch(1)
        full = QPushButton("Open full size")
        full.setObjectName("GhostButton")
        full.clicked.connect(lambda _checked=False: QDesktopServices.openUrl(
            QUrl.fromLocalFile(str(image_path))))
        row.addWidget(full)
        close = QPushButton("Close")
        close.setObjectName("PrimaryButton")
        close.clicked.connect(lambda _checked=False: self.accept())
        row.addWidget(close)
        layout.addLayout(row)

    def _hide(self) -> None:
        self.store.set("show_schedule", False)
        self.hidden = True
        self.accept()


# --------------------------------------------------------------------------
# Dialogs
# --------------------------------------------------------------------------

class WelcomeDialog(QDialog):
    """First-run screen: pick the folder your scripts live in."""

    def __init__(self, store: Store, parent=None):
        super().__init__(parent)
        self.store = store
        self.setObjectName("WelcomeDialog")
        self.setWindowTitle(f"Welcome to {APP_NAME}")
        self.setMinimumWidth(560)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 24)
        layout.setSpacing(14)

        logo = load_logo_pixmap(128)
        if logo:
            mark = QLabel()
            mark.setPixmap(rounded_pixmap(logo, 72, radius=16))
            mark.setAlignment(Qt.AlignLeft)
            layout.addWidget(mark)

        title = QLabel(APP_NAME)
        title.setObjectName("WelcomeTitle")
        layout.addWidget(title)

        subtitle = QLabel(APP_TAGLINE)
        subtitle.setObjectName("WelcomeSubtitle")
        layout.addWidget(subtitle)

        body = QLabel(
            "Choose the folder your scripts live in. Every .py, .bat, .ps1 and .sh file "
            "inside it shows up here automatically - and so does everything you add later.\n\n"
            "You can add more folders at any time from Settings."
        )
        body.setObjectName("WelcomeBody")
        body.setWordWrap(True)
        layout.addWidget(body)

        picker_row = QHBoxLayout()
        picker_row.setSpacing(8)
        self.folder_input = QLineEdit()
        self.folder_input.setObjectName("ArgsInput")
        self.folder_input.setPlaceholderText("No folder selected yet")
        self.folder_input.setReadOnly(True)
        picker_row.addWidget(self.folder_input, 1)

        browse = QPushButton("Choose folder...")
        browse.setObjectName("PrimaryButton")
        browse.setCursor(Qt.PointingHandCursor)
        browse.clicked.connect(lambda _checked=False: self._browse())
        picker_row.addWidget(browse, 0)
        layout.addLayout(picker_row)

        self.recursive_check = QCheckBox("Include scripts in subfolders")
        self.recursive_check.setChecked(bool(store.get("recursive", True)))
        layout.addWidget(self.recursive_check)

        hint = QLabel(
            "Tip: subfolder names become categories, unless a script sets its own "
            "'Category:' line in its header."
        )
        hint.setObjectName("HintLabel")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Open library")
        buttons.button(QDialogButtonBox.Ok).setObjectName("PrimaryButton")
        buttons.button(QDialogButtonBox.Cancel).setObjectName("GhostButton")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        self.ok_button = buttons.button(QDialogButtonBox.Ok)
        self.ok_button.setEnabled(False)
        layout.addWidget(buttons)

    def _browse(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select your scripts folder")
        if folder:
            self.folder_input.setText(folder)
            self.ok_button.setEnabled(True)

    def accept(self) -> None:
        folder = self.folder_input.text().strip()
        if folder:
            self.store.add_folder(folder)
            self.store.set("recursive", self.recursive_check.isChecked())
        super().accept()


class SettingsDialog(QDialog):
    """Folders, interpreter, behaviour, desktop shortcut."""

    def __init__(self, store: Store, parent=None):
        super().__init__(parent)
        self.store = store
        self.setWindowTitle("Settings")
        self.setMinimumWidth(620)
        self.setObjectName("SettingsDialog")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 20)
        layout.setSpacing(12)

        layout.addWidget(self._section("SCRIPT FOLDERS"))
        self.folder_list = QListWidget()
        self.folder_list.setObjectName("FolderList")
        self.folder_list.setMinimumHeight(130)
        for folder in store.folders:
            self.folder_list.addItem(folder)
        layout.addWidget(self.folder_list)

        folder_buttons = QHBoxLayout()
        folder_buttons.setSpacing(8)
        add_button = QPushButton("Add folder...")
        add_button.setObjectName("GhostButton")
        add_button.clicked.connect(lambda _checked=False: self._add_folder())
        folder_buttons.addWidget(add_button)

        remove_button = QPushButton("Remove selected")
        remove_button.setObjectName("GhostButton")
        remove_button.clicked.connect(lambda _checked=False: self._remove_folder())
        folder_buttons.addWidget(remove_button)
        folder_buttons.addStretch(1)
        layout.addLayout(folder_buttons)

        self.recursive_check = QCheckBox("Include scripts in subfolders")
        self.recursive_check.setChecked(bool(store.get("recursive", True)))
        layout.addWidget(self.recursive_check)

        layout.addWidget(self._section("PYTHON INTERPRETER"))
        interpreter_row = QHBoxLayout()
        interpreter_row.setSpacing(8)
        self.interpreter_input = QLineEdit(store.get("interpreter", "") or "")
        self.interpreter_input.setObjectName("ArgsInput")
        self.interpreter_input.setPlaceholderText(
            f"Leave empty to use the current one ({sys.executable})"
        )
        interpreter_row.addWidget(self.interpreter_input, 1)
        pick_interpreter = QPushButton("Browse...")
        pick_interpreter.setObjectName("GhostButton")
        pick_interpreter.clicked.connect(lambda _checked=False: self._pick_interpreter())
        interpreter_row.addWidget(pick_interpreter, 0)
        layout.addLayout(interpreter_row)

        layout.addWidget(self._section("BEHAVIOUR"))
        self.confirm_check = QCheckBox("Ask before running a script")
        self.confirm_check.setChecked(bool(store.get("confirm_on_run", False)))
        layout.addWidget(self.confirm_check)
        self.schedule_check = QCheckBox(
            "Show the release schedule in the sidebar (when a schedule image is in your scripts folder)")
        self.schedule_check.setChecked(bool(store.get("show_schedule", True)))
        layout.addWidget(self.schedule_check)

        layout.addWidget(self._section("LIBRARY"))
        library_row = QHBoxLayout()
        library_row.setSpacing(8)
        hidden_count = len(store.get("hidden_scripts", []))
        self.unhide_button = QPushButton(f"Show hidden scripts again ({hidden_count})")
        self.unhide_button.setObjectName("GhostButton")
        self.unhide_button.setEnabled(hidden_count > 0)
        self.unhide_button.clicked.connect(lambda _checked=False: self._unhide())
        library_row.addWidget(self.unhide_button)

        data_button = QPushButton("Open data folder")
        data_button.setObjectName("GhostButton")
        data_button.setToolTip(
            "Settings, caches and deleted scripts live here."
        )
        data_button.clicked.connect(
            lambda _checked=False: QDesktopServices.openUrl(
                QUrl.fromLocalFile(str(data_dir()))
            )
        )
        library_row.addWidget(data_button)

        log_button = QPushButton("Open log")
        log_button.setObjectName("GhostButton")
        log_button.setToolTip("Everything the launcher did, including every error - "
                              "send this file along when something doesn't work.")
        log_button.clicked.connect(
            lambda _checked=False: QDesktopServices.openUrl(QUrl.fromLocalFile(str(log_path())))
        )
        library_row.addWidget(log_button)
        library_row.addStretch(1)
        layout.addLayout(library_row)

        layout.addWidget(self._section("DESKTOP"))
        shortcut_row = QHBoxLayout()
        shortcut_button = QPushButton("Create desktop shortcut")
        shortcut_button.setObjectName("GhostButton")
        shortcut_button.clicked.connect(lambda _checked=False: self._create_shortcut())
        shortcut_row.addWidget(shortcut_button)
        shortcut_row.addStretch(1)
        layout.addLayout(shortcut_row)

        config_hint = QLabel(f"Settings file: {store.path}")
        config_hint.setObjectName("HintLabel")
        config_hint.setWordWrap(True)
        config_hint.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(config_hint)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setObjectName("PrimaryButton")
        buttons.button(QDialogButtonBox.Cancel).setObjectName("GhostButton")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _section(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("SectionLabel")
        return label

    def _add_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Add a scripts folder")
        if not folder:
            return
        existing = {self.folder_list.item(i).text() for i in range(self.folder_list.count())}
        resolved = str(Path(folder).resolve())
        if resolved not in existing:
            self.folder_list.addItem(resolved)

    def _remove_folder(self) -> None:
        for item in self.folder_list.selectedItems():
            self.folder_list.takeItem(self.folder_list.row(item))

    def _pick_interpreter(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select a Python interpreter")
        if path:
            self.interpreter_input.setText(path)

    def _unhide(self) -> None:
        self.store.unhide_all()
        self.unhide_button.setText("Show hidden scripts again (0)")
        self.unhide_button.setEnabled(False)

    def _create_shortcut(self) -> None:
        ok, message = create_desktop_shortcut()
        if ok:
            QMessageBox.information(self, "Desktop shortcut", message)
        else:
            QMessageBox.warning(self, "Desktop shortcut", message)

    def accept(self) -> None:
        folders = [self.folder_list.item(i).text() for i in range(self.folder_list.count())]
        self.store.data["folders"] = folders
        self.store.data["recursive"] = self.recursive_check.isChecked()
        self.store.data["interpreter"] = self.interpreter_input.text().strip()
        self.store.data["confirm_on_run"] = self.confirm_check.isChecked()
        self.store.data["show_schedule"] = self.schedule_check.isChecked()
        self.store.save()
        super().accept()


# --------------------------------------------------------------------------
# Desktop shortcut
# --------------------------------------------------------------------------

def _write_icon_file(target: Path) -> Path | None:
    logo = load_logo_pixmap(256)
    if logo is None:
        return None
    if logo.save(str(target), "ICO" if target.suffix.lower() == ".ico" else "PNG"):
        return target
    return None


def create_desktop_shortcut() -> tuple[bool, str]:
    """Create a desktop entry that launches this application. Returns (ok, message)."""
    launcher = Path(__file__).resolve()
    desktop = Path.home() / "Desktop"
    if not desktop.is_dir():
        desktop = Path.home()
    system = platform.system()

    try:
        if system == "Windows":
            icon_path = _write_icon_file(launcher.parent / "yakshave.ico")
            pythonw = Path(sys.executable).with_name("pythonw.exe")
            runner = str(pythonw if pythonw.exists() else sys.executable)
            link = desktop / f"{APP_NAME}.lnk"
            vbs = launcher.parent / "_make_shortcut.vbs"
            icon_line = (
                f'link.IconLocation = "{icon_path}"\n' if icon_path else ""
            )
            vbs.write_text(
                'Set shell = CreateObject("WScript.Shell")\n'
                f'Set link = shell.CreateShortcut("{link}")\n'
                f'link.TargetPath = "{runner}"\n'
                f'link.Arguments = """{launcher}"""\n'
                f'link.WorkingDirectory = "{launcher.parent}"\n'
                f'link.Description = "{APP_TAGLINE}"\n'
                f"{icon_line}"
                "link.Save\n",
                encoding="utf-8",
            )
            subprocess.run(["wscript", str(vbs)], check=True, timeout=30)
            vbs.unlink(missing_ok=True)
            return True, f"Shortcut created:\n{link}"

        if system == "Linux":
            icon_path = _write_icon_file(launcher.parent / "yakshave.png")
            entry = desktop / "yakshave.desktop"
            entry.write_text(
                "[Desktop Entry]\n"
                "Type=Application\n"
                f"Name={APP_NAME}\n"
                f"Comment={APP_TAGLINE}\n"
                f'Exec="{sys.executable}" "{launcher}"\n'
                f"Path={launcher.parent}\n"
                f"Icon={icon_path or ''}\n"
                "Terminal=false\n"
                "Categories=Utility;Development;\n",
                encoding="utf-8",
            )
            entry.chmod(0o755)
            return True, f"Desktop entry created:\n{entry}"

        if system == "Darwin":
            script = desktop / f"{APP_NAME}.command"
            script.write_text(
                f'#!/bin/bash\ncd "{launcher.parent}"\n'
                f'"{sys.executable}" "{launcher}"\n',
                encoding="utf-8",
            )
            script.chmod(0o755)
            return True, f"Launcher created:\n{script}"

        return False, f"Unsupported platform: {system}"
    except Exception as error:  # pragma: no cover - platform specific
        return False, f"Could not create the shortcut:\n{error}"


# --------------------------------------------------------------------------
# Main window
# --------------------------------------------------------------------------

class MainWindow(QMainWindow):

    def __init__(self, store: Store):
        super().__init__()
        self.store = store
        self.index = ScriptIndex(store)
        self.cards: list[ScriptCard] = []
        self.current_view = VIEW_ALL
        self.selected_key: str | None = None
        self.search_text = ""

        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(1080, 680)

        logo = load_logo_pixmap(256)
        if logo:
            self.setWindowIcon(QIcon(logo))

        self._build_ui()
        self._build_shortcuts()

        self.watcher = QFileSystemWatcher(self)
        self.watcher.directoryChanged.connect(self._on_folder_changed)
        self.rescan_timer = QTimer(self)
        self.rescan_timer.setSingleShot(True)
        self.rescan_timer.setInterval(600)
        self.rescan_timer.timeout.connect(self.refresh)

        self._restore_geometry()
        self.refresh()
        self.card_container.setFocus()

    # -- construction ------------------------------------------------------
    def _build_ui(self) -> None:
        central = QWidget()
        central.setObjectName("Root")
        self.setCentralWidget(central)

        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_topbar())

        self.vertical_split = QSplitter(Qt.Vertical)
        self.vertical_split.setObjectName("VerticalSplit")
        self.vertical_split.setHandleWidth(1)
        self.vertical_split.setChildrenCollapsible(False)

        body = QWidget()
        body.setObjectName("Body")
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        self.sidebar = Sidebar()
        self.sidebar.view_changed.connect(self._on_view_changed)
        body_layout.addWidget(self.sidebar)

        body_layout.addWidget(self._build_content(), 1)

        self.detail = DetailPanel(self.store)
        self.detail.run_requested.connect(self.run_script)
        self.detail.help_requested.connect(self._show_help)
        self.detail.reveal_requested.connect(self._reveal)
        self.detail.edit_requested.connect(self._open_file)
        body_layout.addWidget(self.detail)

        self.vertical_split.addWidget(body)

        self.console = ConsoleDock()
        self.vertical_split.addWidget(self.console)
        self.vertical_split.setStretchFactor(0, 5)
        self.vertical_split.setStretchFactor(1, 2)
        self.vertical_split.setSizes([620, 210])
        root.addWidget(self.vertical_split, 1)

        root.addWidget(self._build_statusbar())

        console_visible = bool(self.store.get("console_visible", False))
        self.console.setVisible(console_visible)
        self.console_button.setText("Hide console" if console_visible else "Show console")

    def _build_topbar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("TopBar")
        bar.setFixedHeight(68)

        layout = QHBoxLayout(bar)
        layout.setContentsMargins(18, 0, 18, 0)
        layout.setSpacing(14)

        logo = load_logo_pixmap(128)
        if logo:
            mark = QLabel()
            mark.setObjectName("LogoMark")
            mark.setPixmap(rounded_pixmap(logo, 40, radius=10))
            mark.setFixedSize(40, 40)
            layout.addWidget(mark, 0, Qt.AlignVCenter)

        brand_column = QVBoxLayout()
        brand_column.setSpacing(0)
        brand_column.setContentsMargins(0, 0, 0, 0)
        wordmark = QLabel("YAK SHAVE")
        wordmark.setObjectName("Wordmark")
        brand_column.addWidget(wordmark)
        tagline = QLabel(APP_TAGLINE)
        tagline.setObjectName("Tagline")
        brand_column.addWidget(tagline)
        layout.addLayout(brand_column, 0)

        layout.addStretch(1)

        self.search_input = QLineEdit()
        self.search_input.setObjectName("SearchInput")
        self.search_input.setPlaceholderText("Search scripts, tags, categories...   Ctrl+F")
        self.search_input.setFixedWidth(300)
        self.search_input.setClearButtonEnabled(True)
        self.search_input.textChanged.connect(self._on_search)
        layout.addWidget(self.search_input, 0, Qt.AlignVCenter)

        refresh_button = QPushButton("Refresh")
        refresh_button.setObjectName("GhostButton")
        refresh_button.setCursor(Qt.PointingHandCursor)
        refresh_button.setToolTip("Rescan the script folders (F5)")
        refresh_button.clicked.connect(lambda _checked=False: self.refresh())
        layout.addWidget(refresh_button, 0, Qt.AlignVCenter)

        settings_button = QPushButton("Settings")
        settings_button.setObjectName("GhostButton")
        settings_button.setCursor(Qt.PointingHandCursor)
        settings_button.clicked.connect(lambda _checked=False: self.open_settings())
        layout.addWidget(settings_button, 0, Qt.AlignVCenter)

        return bar

    def _build_content(self) -> QWidget:
        content = QWidget()
        content.setObjectName("Content")
        layout = QVBoxLayout(content)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        toolbar = QFrame()
        toolbar.setObjectName("ContentToolbar")
        toolbar.setFixedHeight(56)
        toolbar_layout = QHBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(20, 0, 20, 0)
        toolbar_layout.setSpacing(10)

        self.view_title = QLabel("All scripts")
        self.view_title.setObjectName("ViewTitle")
        toolbar_layout.addWidget(self.view_title, 0)

        self.view_count = QLabel("")
        self.view_count.setObjectName("ViewCount")
        toolbar_layout.addWidget(self.view_count, 0)

        toolbar_layout.addStretch(1)

        sort_label = QLabel("Sort")
        sort_label.setObjectName("ToolbarLabel")
        toolbar_layout.addWidget(sort_label, 0)

        self.sort_combo = QComboBox()
        self.sort_combo.setObjectName("SortCombo")
        self.sort_combo.setCursor(Qt.PointingHandCursor)
        for key, label in SORT_MODES:
            self.sort_combo.addItem(label, key)
        saved_sort = self.store.get("sort", "modified")
        matching = self.sort_combo.findData(saved_sort)
        self.sort_combo.setCurrentIndex(matching if matching >= 0 else 0)
        self.sort_combo.currentIndexChanged.connect(self._on_sort_changed)
        toolbar_layout.addWidget(self.sort_combo, 0)

        self.density_button = QPushButton("Compact")
        self.density_button.setObjectName("GhostButton")
        self.density_button.setCheckable(True)
        self.density_button.setCursor(Qt.PointingHandCursor)
        self.density_button.setChecked(self.store.get("view_mode", "list") == "compact")
        self.density_button.clicked.connect(lambda _checked=False: self._on_density_toggled())
        toolbar_layout.addWidget(self.density_button, 0)

        layout.addWidget(toolbar)

        self.scroll = QScrollArea()
        self.scroll.setObjectName("CardScroll")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.card_container = QWidget()
        self.card_container.setObjectName("CardContainer")
        self.card_layout = QVBoxLayout(self.card_container)
        self.card_layout.setContentsMargins(20, 16, 20, 20)
        self.card_layout.setSpacing(10)
        self.card_layout.addStretch(1)
        self.scroll.setWidget(self.card_container)
        layout.addWidget(self.scroll, 1)

        self.empty_state = QLabel()
        self.empty_state.setObjectName("EmptyState")
        self.empty_state.setAlignment(Qt.AlignCenter)
        self.empty_state.setWordWrap(True)
        self.empty_state.setVisible(False)
        layout.addWidget(self.empty_state, 1)

        return content

    def _build_statusbar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("StatusBar")
        bar.setFixedHeight(34)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(18, 0, 12, 0)
        layout.setSpacing(12)

        self.status_label = QLabel("")
        self.status_label.setObjectName("StatusText")
        layout.addWidget(self.status_label, 0)

        layout.addStretch(1)

        self.running_label = QLabel("")
        self.running_label.setObjectName("StatusRunning")
        layout.addWidget(self.running_label, 0)

        self.console_button = QPushButton("Hide console")
        self.console_button.setObjectName("StatusButton")
        self.console_button.setCursor(Qt.PointingHandCursor)
        self.console_button.clicked.connect(lambda _checked=False: self.toggle_console())
        layout.addWidget(self.console_button, 0)

        return bar

    def _build_shortcuts(self) -> None:
        QShortcut(QKeySequence("Ctrl+F"), self, activated=self._focus_search)
        QShortcut(QKeySequence("F5"), self, activated=self.refresh)
        QShortcut(QKeySequence("Ctrl+R"), self, activated=self.refresh)
        QShortcut(QKeySequence("Ctrl+,"), self, activated=self.open_settings)
        QShortcut(QKeySequence("F8"), self, activated=self.toggle_console)
        QShortcut(QKeySequence("Escape"), self, activated=self._clear_search)
        QShortcut(QKeySequence("Ctrl+Q"), self, activated=self.close)

    # -- data flow ---------------------------------------------------------
    def _update_schedule_row(self) -> None:
        show = bool(self.store.get("show_schedule", True))
        path = find_schedule(self.store.folders) if show else None
        row = self.sidebar.rows[VIEW_SCHEDULE]
        row.setVisible(path is not None)
        if path is not None:
            match = re.search(r"(\d{2})\.(\d{4})", path.stem)
            row.count.setText(f"{match.group(1)}.{match.group(2)[2:]}" if match else "")

    def refresh(self) -> None:
        self.index.scan()
        self._update_watcher()
        self._rebuild()
        self._update_schedule_row()

    def _update_watcher(self) -> None:
        existing = self.watcher.directories()
        if existing:
            self.watcher.removePaths(existing)
        paths = self.index.watch_paths()
        if paths:
            self.watcher.addPaths(paths)

    def _on_folder_changed(self, _path: str) -> None:
        self.rescan_timer.start()

    def _visible_scripts(self) -> list[ScriptMeta]:
        scripts = list(self.index.scripts)

        if self.current_view == VIEW_FAVOURITES:
            scripts = [s for s in scripts if self.store.is_favourite(s.key)]
        elif self.current_view == VIEW_RECENT:
            scripts = [s for s in scripts if self.store.stats_for(s.key).get("last")]
        elif self.current_view.startswith(SUITE_PREFIX):
            suite_name = self.current_view[len(SUITE_PREFIX):]
            scripts = [s for s in scripts if s.suite == suite_name]
        elif self.current_view != VIEW_ALL:
            scripts = [s for s in scripts if s.category == self.current_view]

        if self.search_text:
            needles = self.search_text.lower().split()
            scripts = [s for s in scripts if all(n in s.haystack() for n in needles)]

        sort_key = self.sort_combo.currentData() if hasattr(self, "sort_combo") else "modified"
        if self.current_view == VIEW_RECENT:
            sort_key = "lastrun"

        # Inside a suite the order is the suite's own: hub first, then the
        # steps in the order their headers give.
        if self.current_view.startswith(SUITE_PREFIX):
            scripts.sort(key=lambda s: (not s.is_hub, s.suite_order, s.name.lower()))
            return scripts

        if sort_key == "name":
            scripts.sort(key=lambda s: (-s.order, s.name.lower()))
        elif sort_key == "category":
            scripts.sort(key=lambda s: (s.category.lower(), s.name.lower()))
        elif sort_key == "lastrun":
            scripts.sort(key=lambda s: self.store.stats_for(s.key).get("last", 0), reverse=True)
        elif sort_key == "runs":
            scripts.sort(key=lambda s: self.store.stats_for(s.key).get("runs", 0), reverse=True)
        else:
            scripts.sort(key=lambda s: s.mtime, reverse=True)
        return scripts

    def _rebuild(self) -> None:
        for card in self.cards:
            card.setParent(None)
            card.deleteLater()
        self.cards = []

        scripts = self._visible_scripts()
        compact = self.density_button.isChecked()

        for script in scripts:
            card = ScriptCard(script, self.store, compact=compact)
            card.activated.connect(self._on_card_activated)
            card.selected.connect(self._on_card_selected)
            card.favourite_toggled.connect(self._on_favourite_toggled)
            card.context_requested.connect(self._on_card_context)
            card.set_selected(script.key == self.selected_key)
            self.card_layout.insertWidget(self.card_layout.count() - 1, card)
            self.cards.append(card)

        has_scripts = bool(scripts)
        self.scroll.setVisible(has_scripts)
        self.empty_state.setVisible(not has_scripts)
        if not has_scripts:
            self.empty_state.setText(self._empty_message())

        favourites = sum(1 for s in self.index.scripts if self.store.is_favourite(s.key))
        recent = sum(1 for s in self.index.scripts if self.store.stats_for(s.key).get("last"))
        self.sidebar.set_counts(
            len(self.index.scripts), favourites, recent,
            self.index.categories(), self.index.suites()
        )

        titles = {
            VIEW_ALL: "All scripts",
            VIEW_FAVOURITES: "Favourites",
            VIEW_RECENT: "Recently run",
        }
        if self.current_view.startswith(SUITE_PREFIX):
            title = f"{self.current_view[len(SUITE_PREFIX):]} suite"
        else:
            title = titles.get(self.current_view, self.current_view)
        self.view_title.setText(title)
        self.view_count.setText(
            f"{len(scripts)} of {len(self.index.scripts)}" if self.search_text
            else f"{len(scripts)}"
        )

        selected = next((s for s in scripts if s.key == self.selected_key), None)
        self.detail.show_script(selected)

        folders = len(self.store.folders)
        status = (
            f"{len(self.index.scripts)} scripts  ·  "
            f"{len(self.index.categories())} categories  ·  "
            f"{folders} folder{'s' if folders != 1 else ''}"
        )
        if self.index.errors:
            status += f"  ·  {len(self.index.errors)} folder issue(s)"
        self.status_label.setText(status)
        self._update_running_label()

    def _empty_message(self) -> str:
        if not self.store.folders:
            return (
                "No script folder configured yet.\n\n"
                "Open Settings and add the folder your scripts live in."
            )
        if self.search_text:
            return f"Nothing matches '{self.search_text}'."
        if self.current_view == VIEW_FAVOURITES:
            return "No favourites yet.\n\nClick the star on a card to pin it here."
        if self.current_view == VIEW_RECENT:
            return "Nothing has been run yet."
        if self.current_view.startswith(SUITE_PREFIX):
            return "No scripts from this suite are in your folders."
        return (
            "No scripts found in this folder.\n\n"
            "Supported types: .py  .pyw  .bat  .cmd  .ps1  .sh"
        )

    def _update_running_label(self) -> None:
        count = self.console.running_count()
        self.running_label.setText(f"{count} running" if count else "")

    # -- events ------------------------------------------------------------
    def _on_view_changed(self, key: str) -> None:
        if key == VIEW_SCHEDULE:
            self.sidebar.set_current(self.current_view)     # keep the list where it was
            path = find_schedule(self.store.folders)
            if path is None:
                return
            LOG.info("Schedule shown: %s", path)
            dialog = ScheduleDialog(path, self.store, self)
            dialog.exec()
            if dialog.hidden:
                self._update_schedule_row()
            return
        self.current_view = key
        self._rebuild()
        self.scroll.verticalScrollBar().setValue(0)

    def _on_search(self, text: str) -> None:
        self.search_text = text.strip()
        self._rebuild()

    def _on_sort_changed(self, _index: int) -> None:
        self.store.set("sort", self.sort_combo.currentData())
        self._rebuild()

    def _on_density_toggled(self) -> None:
        self.store.set("view_mode", "compact" if self.density_button.isChecked() else "list")
        self._rebuild()

    def _on_card_selected(self, meta: ScriptMeta) -> None:
        self.selected_key = meta.key
        for card in self.cards:
            card.set_selected(card.meta.key == meta.key)
        self.detail.show_script(meta)

    def _on_card_activated(self, meta: ScriptMeta) -> None:
        self._on_card_selected(meta)
        saved = self.store.saved_args(meta.key) or meta.default_args
        self.run_script(meta, saved, meta.terminal)

    def _on_favourite_toggled(self, meta: ScriptMeta) -> None:
        self.store.toggle_favourite(meta.key)
        self._rebuild()

    def _on_card_context(self, meta: ScriptMeta, position: QPoint) -> None:
        menu = QMenu(self)
        menu.setObjectName("CardMenu")

        run_action = menu.addAction("Run")
        terminal_action = menu.addAction("Run in external terminal")
        menu.addSeparator()
        favourite_action = menu.addAction(
            "Remove from favourites" if self.store.is_favourite(meta.key)
            else "Add to favourites"
        )
        menu.addSeparator()
        help_action = menu.addAction("Show help (--help)")
        open_action = menu.addAction("Open file")
        reveal_action = menu.addAction("Show in folder")
        copy_action = menu.addAction("Copy full path")
        menu.addSeparator()
        hide_action = menu.addAction("Hide from library")
        delete_action = menu.addAction("Delete script...")

        chosen = menu.exec(position)
        if chosen is None:
            return
        if chosen == help_action:
            self._show_help(meta)
            return
        if chosen == hide_action:
            self._hide_script(meta)
            return
        if chosen == delete_action:
            self._delete_script(meta)
            return
        if chosen == run_action:
            self.run_script(meta, self.store.saved_args(meta.key) or meta.default_args, False)
        elif chosen == terminal_action:
            self.run_script(meta, self.store.saved_args(meta.key) or meta.default_args, True)
        elif chosen == favourite_action:
            self._on_favourite_toggled(meta)
        elif chosen == open_action:
            self._open_file(meta)
        elif chosen == reveal_action:
            self._reveal(meta)
        elif chosen == copy_action:
            QApplication.clipboard().setText(str(meta.path))

    def _show_help(self, meta: ScriptMeta) -> None:
        """Run the script with --help only - it prints what it accepts and exits."""
        self.run_script(meta, "--help", False, count_run=False)

    def _hide_script(self, meta: ScriptMeta) -> None:
        """Keep the file, drop it from the library. Reversible from Settings."""
        self.store.hide_script(meta.key)
        if self.selected_key == meta.key:
            self.selected_key = None
        self.refresh()
        self.status_label.setText(
            f"'{meta.name}' hidden. Bring it back from Settings."
        )

    def _delete_script(self, meta: ScriptMeta) -> None:
        """Move a script file out of the library, into the data folder's trash.

        Not a real delete: the file is recoverable until the user empties that
        folder themselves. A launcher that can silently destroy a script is a
        launcher nobody should trust.
        """
        answer = QMessageBox.question(
            self,
            "Delete script",
            f"Move '{meta.name}' out of your scripts folder?\n\n{meta.path}\n\n"
            f"It goes to the Yak Shave trash folder, so you can still get it back.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        trash = data_dir() / "_trash" / time.strftime("%Y-%m-%d")
        try:
            trash.mkdir(parents=True, exist_ok=True)
            target = trash / meta.path.name
            counter = 2
            while target.exists():
                target = trash / f"{meta.path.stem} ({counter}){meta.path.suffix}"
                counter += 1
            meta.path.replace(target)
        except OSError as error:
            QMessageBox.warning(self, "Could not delete", str(error))
            return

        self.store.forget_script(meta.key)
        if self.selected_key == meta.key:
            self.selected_key = None
        self.refresh()
        self.status_label.setText(f"'{meta.name}' moved to {target}")

    def _focus_search(self) -> None:
        self.search_input.setFocus()
        self.search_input.selectAll()

    def _clear_search(self) -> None:
        if self.search_input.text():
            self.search_input.clear()

    def toggle_console(self) -> None:
        visible = not self.console.isVisible()
        self.console.setVisible(visible)
        self.console_button.setText("Hide console" if visible else "Show console")
        self.store.set("console_visible", visible)

    def open_settings(self) -> None:
        dialog = SettingsDialog(self.store, self)
        if dialog.exec() == QDialog.Accepted:
            self.refresh()

    # -- running -----------------------------------------------------------
    def _interpreter(self) -> str:
        configured = (self.store.get("interpreter") or "").strip()
        return child_interpreter(configured or sys.executable)

    def _build_command(self, meta: ScriptMeta, args: str) -> list[str] | None:
        extra = split_arguments(args)

        if meta.kind == "python":
            return [self._interpreter(), str(meta.path), *extra]
        if meta.kind == "batch":
            if os.name == "nt":
                return ["cmd.exe", "/c", str(meta.path), *extra]
            return None
        if meta.kind == "powershell":
            executable = "powershell.exe" if os.name == "nt" else "pwsh"
            return [executable, "-ExecutionPolicy", "Bypass", "-File", str(meta.path), *extra]
        if meta.kind == "shell":
            return ["bash", str(meta.path), *extra]
        return None

    def run_script(self, meta: ScriptMeta, args: str = "", in_terminal: bool = False,
                   count_run: bool = True) -> None:
        command = self._build_command(meta, args)
        if command is None:
            QMessageBox.warning(
                self,
                "Cannot run this script",
                f"{meta.path.suffix} files are not supported on this platform.",
            )
            return

        if self.store.get("confirm_on_run", False):
            answer = QMessageBox.question(
                self,
                "Run script",
                f"Run '{meta.name}'?\n\n{' '.join(command)}",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if answer != QMessageBox.Yes:
                return

        if count_run:
            self.store.record_run(meta.key)

        if in_terminal:
            if self._run_in_terminal(command, meta.path.parent):
                self._rebuild()
            return

        if not self.console.isVisible():
            self.toggle_console()

        tab = RunTab(meta, command, meta.path.parent)
        tab.finished.connect(lambda _tab: self._update_running_label())
        self.console.add_run(tab, meta.name)
        tab.start()
        self._update_running_label()
        self._rebuild()

    def _run_in_terminal(self, command: list[str], workdir: Path) -> bool:
        try:
            if os.name == "nt":
                quoted = " ".join(f'"{part}"' for part in command)
                subprocess.Popen(
                    f'start "" cmd /k {quoted}', cwd=str(workdir), shell=True
                )
                return True
            for terminal in ("x-terminal-emulator", "gnome-terminal", "konsole", "xterm"):
                try:
                    subprocess.Popen([terminal, "-e", *command], cwd=str(workdir))
                    return True
                except FileNotFoundError:
                    continue
            QMessageBox.warning(
                self, "No terminal found",
                "Could not find a terminal emulator to run this script in."
            )
            return False
        except Exception as error:
            QMessageBox.warning(self, "Could not start", str(error))
            return False

    # -- file actions ------------------------------------------------------
    def _open_file(self, meta: ScriptMeta) -> None:
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(meta.path)))

    def _reveal(self, meta: ScriptMeta) -> None:
        try:
            if os.name == "nt":
                subprocess.Popen(["explorer", "/select,", str(meta.path)])
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", "-R", str(meta.path)])
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(meta.path.parent)))
        except Exception:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(meta.path.parent)))

    # -- geometry ----------------------------------------------------------
    def _restore_geometry(self) -> None:
        geometry = self.store.get("window", {}) or {}
        width = int(geometry.get("w", 1320))
        height = int(geometry.get("h", 820))
        self.resize(width, height)
        if "x" in geometry and "y" in geometry:
            self.move(int(geometry["x"]), int(geometry["y"]))

    def closeEvent(self, event) -> None:
        running = self.console.running_count()
        if running:
            answer = QMessageBox.question(
                self,
                "Scripts still running",
                f"{running} script(s) are still running. Stop them and quit?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                event.ignore()
                return
            self.console.stop_all()

        self.store.data["window"] = {
            "x": self.x(), "y": self.y(), "w": self.width(), "h": self.height()
        }
        self.store.save()
        super().closeEvent(event)


# --------------------------------------------------------------------------
# Stylesheet
# --------------------------------------------------------------------------

class YakStyle(QProxyStyle):
    """Draws the check boxes ourselves so they match the dark theme exactly."""

    def pixelMetric(self, metric, option=None, widget=None):
        if metric in (QStyle.PM_IndicatorWidth, QStyle.PM_IndicatorHeight):
            return 16
        return super().pixelMetric(metric, option, widget)

    def drawPrimitive(self, element, option, painter, widget=None):
        if element == QStyle.PE_IndicatorCheckBox:
            rect = option.rect.adjusted(1, 1, -1, -1)
            checked = bool(option.state & QStyle.State_On)
            painter.save()
            painter.setRenderHint(QPainter.Antialiasing, True)
            painter.setPen(QPen(QColor(Theme.ACCENT if checked else Theme.BORDER_STRONG), 1.3))
            painter.setBrush(QColor(Theme.ACCENT) if checked else QColor(Theme.SURFACE))
            painter.drawRoundedRect(rect, 4, 4)
            if checked:
                pen = QPen(QColor("#14100B"), 1.9)
                pen.setCapStyle(Qt.RoundCap)
                pen.setJoinStyle(Qt.RoundJoin)
                painter.setPen(pen)
                x, y = rect.x(), rect.y()
                w, h = rect.width(), rect.height()
                painter.drawLine(x + w * 0.24, y + h * 0.53, x + w * 0.43, y + h * 0.72)
                painter.drawLine(x + w * 0.43, y + h * 0.72, x + w * 0.77, y + h * 0.29)
            painter.restore()
            return
        super().drawPrimitive(element, option, painter, widget)


def build_palette() -> QPalette:
    """A dark palette so widgets drawn by the Fusion style match the stylesheet."""
    t = Theme
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(t.BG))
    palette.setColor(QPalette.WindowText, QColor(t.TEXT))
    palette.setColor(QPalette.Base, QColor(t.SURFACE))
    palette.setColor(QPalette.AlternateBase, QColor(t.BG_ALT))
    palette.setColor(QPalette.Text, QColor(t.TEXT))
    palette.setColor(QPalette.Button, QColor(t.SURFACE))
    palette.setColor(QPalette.ButtonText, QColor(t.TEXT))
    palette.setColor(QPalette.Highlight, QColor(t.ACCENT))
    palette.setColor(QPalette.HighlightedText, QColor("#14100B"))
    palette.setColor(QPalette.ToolTipBase, QColor(t.SURFACE))
    palette.setColor(QPalette.ToolTipText, QColor(t.TEXT))
    palette.setColor(QPalette.PlaceholderText, QColor(t.TEXT_MUTED))
    palette.setColor(QPalette.Disabled, QPalette.Text, QColor(t.TEXT_MUTED))
    palette.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(t.TEXT_MUTED))
    return palette


def build_stylesheet() -> str:
    t = Theme
    return f"""
/* Every rule is scoped to an object or class name on purpose: an unscoped
   rule would also repaint every child widget inside it. */

QWidget#Root, QWidget#Body, QWidget#Content {{
    background: {t.BG};
}}

QFrame#TopBar {{
    background: {t.BG_ALT};
    border-bottom: 1px solid {t.BORDER};
}}
QLabel#Wordmark {{
    color: {t.TEXT};
    font-size: 17px;
    font-weight: 700;
    letter-spacing: 2px;
}}
QLabel#Tagline {{
    color: {t.TEXT_MUTED};
    font-size: 11px;
}}

QLineEdit#SearchInput, QLineEdit#ArgsInput, QLineEdit#StdinInput {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER};
    border-radius: {t.RADIUS_SM}px;
    padding: 7px 10px;
    color: {t.TEXT};
    selection-background-color: {t.ACCENT};
}}
QLineEdit#SearchInput:focus, QLineEdit#ArgsInput:focus, QLineEdit#StdinInput:focus {{
    border: 1px solid {t.ACCENT};
}}
QLineEdit#SearchInput::placeholder {{ color: {t.TEXT_MUTED}; }}

QWidget#Sidebar {{
    background: {t.BG_ALT};
    border-right: 1px solid {t.BORDER};
}}
QLabel#SectionLabel {{
    color: {t.TEXT_MUTED};
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1.4px;
    padding: 6px 8px 4px 8px;
}}
QScrollArea#CategoryScroll, QWidget#CategoryContainer {{
    background: transparent;
    border: none;
}}
QFrame#NavRow {{
    background: transparent;
    border: none;
    border-radius: {t.RADIUS_SM}px;
}}
QFrame#NavRow:hover {{ background: {t.SURFACE}; }}
QFrame#NavRow[active="true"] {{ background: {t.SURFACE_ACTIVE}; }}
QLabel#NavRowLabel {{ color: {t.TEXT_DIM}; font-size: 13px; }}
QLabel#NavRowLabel[active="true"] {{ color: {t.ACCENT}; font-weight: 600; }}
QLabel#NavRowCount {{ color: {t.TEXT_MUTED}; font-size: 11px; }}
QLabel#SidebarFooter {{
    color: {t.TEXT_MUTED};
    font-size: 10px;
    padding: 8px;
}}

QFrame#ContentToolbar {{
    background: {t.BG};
    border-bottom: 1px solid {t.BORDER};
}}
QLabel#ViewTitle {{
    color: {t.TEXT};
    font-size: 15px;
    font-weight: 600;
}}
QLabel#ViewCount {{
    color: {t.TEXT_MUTED};
    font-size: 12px;
    padding-top: 2px;
}}
QLabel#ToolbarLabel {{
    color: {t.TEXT_MUTED};
    font-size: 12px;
}}
QComboBox#SortCombo {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER};
    border-radius: {t.RADIUS_SM}px;
    color: {t.TEXT_DIM};
    padding: 6px 10px;
    min-width: 130px;
}}
QComboBox#SortCombo:hover {{ border: 1px solid {t.BORDER_STRONG}; color: {t.TEXT}; }}
QComboBox#SortCombo QAbstractItemView {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER};
    color: {t.TEXT};
    selection-background-color: {t.SURFACE_ACTIVE};
    selection-color: {t.ACCENT};
    outline: none;
}}

QScrollArea#CardScroll, QWidget#CardContainer, QScrollArea#DetailScroll {{
    background: {t.BG};
    border: none;
}}

QFrame#ScriptCard {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER};
    border-radius: {t.RADIUS}px;
}}
QFrame#ScriptCard:hover {{
    background: {t.SURFACE_HOVER};
    border: 1px solid {t.BORDER_STRONG};
}}
QFrame#ScriptCard[selected="true"] {{
    background: {t.SURFACE_HOVER};
    border: 1px solid {t.ACCENT};
}}
QLabel#CardBadge {{
    background: {t.ACCENT_SOFT};
    color: {t.ACCENT};
    border: 1px solid {t.BORDER};
    border-radius: {t.RADIUS_SM}px;
    font-size: 13px;
    font-weight: 700;
}}
QLabel#CardBadgeSmall {{
    background: {t.ACCENT_SOFT};
    color: {t.ACCENT};
    border: 1px solid {t.BORDER};
    border-radius: 5px;
    font-size: 11px;
    font-weight: 700;
}}
QLabel#CardTitle {{
    color: {t.TEXT};
    font-size: 14px;
    font-weight: 600;
}}
QLabel#CardDescription {{
    color: {t.TEXT_DIM};
    font-size: 12px;
}}
QLabel#CardDescriptionEmpty {{
    color: {t.TEXT_MUTED};
    font-size: 12px;
    font-style: italic;
}}
QLabel#CardFooter {{
    color: {t.TEXT_MUTED};
    font-size: 11px;
}}
QLabel#CategoryChip {{
    background: {t.BG_ALT};
    border: 1px solid {t.BORDER};
    border-radius: 10px;
    color: {t.TEXT_DIM};
    font-size: 11px;
    padding: 2px 9px;
}}
QLabel#KindChip {{
    background: transparent;
    border: 1px solid {t.BORDER_STRONG};
    border-radius: 4px;
    color: {t.TEXT_MUTED};
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 0.5px;
    padding: 1px 5px;
}}
QLabel#MetaChip {{
    color: {t.TEXT_MUTED};
    font-size: 11px;
}}
QLabel#SuiteChip {{
    background: {t.ACCENT_SOFT};
    border: 1px solid {t.BORDER};
    border-radius: 10px;
    color: {t.ACCENT};
    font-size: 11px;
    padding: 2px 9px;
}}
QLabel#HubChip {{
    background: {t.ACCENT};
    border: none;
    border-radius: 4px;
    color: #14100B;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 0.5px;
    padding: 1px 5px;
}}
QWidget#SuiteContainer {{ background: transparent; }}
QToolButton#StarButton {{
    background: transparent;
    border: 1px solid transparent;
    border-radius: {t.RADIUS_SM}px;
}}
QToolButton#StarButton:hover {{ background: {t.SURFACE_ACTIVE}; border: 1px solid {t.BORDER}; }}
QPushButton#CardRunButton {{
    background: {t.SURFACE_ACTIVE};
    border: 1px solid {t.BORDER_STRONG};
    border-radius: {t.RADIUS_SM}px;
    color: {t.TEXT};
    font-size: 12px;
    font-weight: 600;
    padding: 7px 16px;
}}
QPushButton#CardRunButton:hover {{
    background: {t.ACCENT};
    border: 1px solid {t.ACCENT};
    color: #11130F;
}}

QLabel#EmptyState {{
    color: {t.TEXT_MUTED};
    font-size: 13px;
    padding: 40px;
}}

QWidget#DetailPanel, QWidget#DetailContainer {{
    background: {t.BG_ALT};
    border-left: 1px solid {t.BORDER};
}}
QLabel#DetailTitle {{ color: {t.TEXT}; font-size: 18px; font-weight: 700; }}
QLabel#DetailSubtitle {{ color: {t.ACCENT}; font-size: 12px; }}
QLabel#DetailDescription {{ color: {t.TEXT_DIM}; font-size: 12px; }}
QLabel#DetailTags {{ color: {t.TEXT_MUTED}; font-size: 11px; }}
QLabel#DetailFacts {{ color: {t.TEXT_DIM}; font-size: 11px; font-family: monospace; }}
QLabel#DetailEmpty {{ color: {t.TEXT_MUTED}; font-size: 12px; }}
QFrame#Divider {{ background: {t.BORDER}; border: none; }}

QPushButton#PrimaryButton {{
    background: {t.ACCENT};
    border: none;
    border-radius: {t.RADIUS_SM}px;
    color: #14100B;
    font-size: 13px;
    font-weight: 700;
    padding: 10px 18px;
}}
QPushButton#PrimaryButton:hover {{ background: {t.ACCENT_HOVER}; }}
QPushButton#PrimaryButton:pressed {{ background: {t.ACCENT_PRESSED}; }}
QPushButton#PrimaryButton:disabled {{ background: {t.SURFACE_ACTIVE}; color: {t.TEXT_MUTED}; }}

QPushButton#GhostButton {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER};
    border-radius: {t.RADIUS_SM}px;
    color: {t.TEXT_DIM};
    font-size: 12px;
    padding: 8px 14px;
}}
QPushButton#GhostButton:hover {{
    background: {t.SURFACE_HOVER};
    border: 1px solid {t.BORDER_STRONG};
    color: {t.TEXT};
}}
QPushButton#GhostButton:checked {{
    background: {t.SURFACE_ACTIVE};
    border: 1px solid {t.ACCENT};
    color: {t.ACCENT};
}}

QCheckBox {{
    color: {t.TEXT_DIM};
    font-size: 12px;
    spacing: 8px;
}}
/* The indicator itself is left to the Fusion style so it keeps its tick mark;
   the palette below gives it the right colours. */

QWidget#ConsoleDock {{
    background: {t.BG_ALT};
    border-top: 1px solid {t.BORDER};
}}
QTabWidget#ConsoleTabs::pane {{
    border: none;
    background: {t.BG_ALT};
}}
QTabWidget#ConsoleTabs QTabBar::tab {{
    background: transparent;
    border: none;
    border-bottom: 2px solid transparent;
    color: {t.TEXT_MUTED};
    font-size: 12px;
    padding: 9px 14px;
}}
QTabWidget#ConsoleTabs QTabBar::tab:selected {{
    color: {t.TEXT};
    border-bottom: 2px solid {t.ACCENT};
}}
QTabWidget#ConsoleTabs QTabBar::tab:hover {{ color: {t.TEXT}; }}
QToolButton#TabCloseButton {{
    background: transparent;
    border: none;
    border-radius: 3px;
    margin-left: 2px;
}}
QToolButton#TabCloseButton:hover {{ background: {t.SURFACE_ACTIVE}; }}
QLabel#ConsolePlaceholder {{ color: {t.TEXT_MUTED}; font-size: 12px; }}
QWidget#RunTab {{ background: {t.BG_ALT}; }}
QPlainTextEdit#ConsoleOutput {{
    background: {t.BG};
    border: 1px solid {t.BORDER};
    border-radius: {t.RADIUS_SM}px;
    color: {t.TEXT_DIM};
    padding: 8px;
    selection-background-color: {t.ACCENT};
}}
QLabel#RunCommand {{ color: {t.TEXT_MUTED}; font-size: 11px; }}
QLabel#StdinLabel {{ color: {t.TEXT_DIM}; font-size: 12px; }}
QLabel#RunStatusRunning {{ color: {t.ACCENT}; font-size: 12px; font-weight: 700; }}
QLabel#RunStatusDone {{ color: {t.OK}; font-size: 12px; font-weight: 700; }}
QLabel#RunStatusFailed {{ color: {t.ERROR}; font-size: 12px; font-weight: 700; }}

QFrame#StatusBar {{
    background: {t.BG_ALT};
    border-top: 1px solid {t.BORDER};
}}
QLabel#StatusText {{ color: {t.TEXT_MUTED}; font-size: 11px; }}
QLabel#StatusRunning {{ color: {t.ACCENT}; font-size: 11px; font-weight: 600; }}
QPushButton#StatusButton {{
    background: transparent;
    border: none;
    color: {t.TEXT_MUTED};
    font-size: 11px;
    padding: 4px 8px;
}}
QPushButton#StatusButton:hover {{ color: {t.ACCENT}; }}

QDialog#WelcomeDialog, QDialog#SettingsDialog {{ background: {t.BG}; }}
QLabel#WelcomeTitle {{
    color: {t.TEXT}; font-size: 26px; font-weight: 700; letter-spacing: 1px;
}}
QLabel#WelcomeSubtitle {{ color: {t.ACCENT}; font-size: 13px; }}
QLabel#WelcomeBody {{ color: {t.TEXT_DIM}; font-size: 13px; }}
QLabel#HintLabel {{ color: {t.TEXT_MUTED}; font-size: 11px; }}
QListWidget#FolderList {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER};
    border-radius: {t.RADIUS_SM}px;
    color: {t.TEXT_DIM};
    padding: 4px;
    outline: none;
}}
QListWidget#FolderList::item {{ padding: 6px 8px; border-radius: 4px; }}
QListWidget#FolderList::item:selected {{ background: {t.SURFACE_ACTIVE}; color: {t.ACCENT}; }}

QMenu#CardMenu {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER_STRONG};
    border-radius: {t.RADIUS_SM}px;
    color: {t.TEXT_DIM};
    padding: 6px;
}}
QMenu#CardMenu::item {{ padding: 7px 24px 7px 14px; border-radius: 4px; }}
QMenu#CardMenu::item:selected {{ background: {t.SURFACE_ACTIVE}; color: {t.ACCENT}; }}
QMenu#CardMenu::separator {{ height: 1px; background: {t.BORDER}; margin: 5px 4px; }}

QScrollBar:vertical {{
    background: transparent; width: 10px; margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: {t.BORDER_STRONG}; border-radius: 5px; min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{ background: {t.TEXT_MUTED}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{
    background: {t.BORDER_STRONG}; border-radius: 5px; min-width: 30px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

QSplitter#VerticalSplit::handle {{ background: {t.BORDER}; }}

QMessageBox {{ background: {t.BG_ALT}; }}
QMessageBox QLabel {{ color: {t.TEXT}; }}
QMessageBox QPushButton {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER_STRONG};
    border-radius: {t.RADIUS_SM}px;
    color: {t.TEXT};
    padding: 7px 16px;
    min-width: 76px;
}}
QMessageBox QPushButton:hover {{ background: {t.SURFACE_HOVER}; }}
QToolTip {{
    background: {t.SURFACE};
    border: 1px solid {t.BORDER_STRONG};
    color: {t.TEXT};
    padding: 5px 8px;
}}
"""


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def report_startup_failure(error: BaseException) -> None:
    """Show what went wrong, and write it down.

    Started from a desktop shortcut there is no console, so an unhandled
    exception would otherwise just be a window that never appears.
    """
    details = "".join(traceback.format_exception(type(error), error, error.__traceback__))
    LOG.error("Startup failed:\n%s", details)
    log_path = Path(__file__).resolve().parent / "yakshave_error.log"
    try:
        log_path.write_text(details, encoding="utf-8")
    except OSError:
        log_path = None

    message = (
        f"{APP_NAME} could not start.\n\n"
        f"{type(error).__name__}: {error}\n\n"
    )
    if log_path:
        message += f"Full details written to:\n{log_path}"

    try:
        QApplication.instance() or QApplication(sys.argv)
        QMessageBox.critical(None, f"{APP_NAME} - startup failed", message)
    except Exception:
        sys.stderr.write(message + "\n" + details)


def main() -> int:
    setup_logging()
    QApplication.setAttribute(Qt.AA_DontShowIconsInMenus, False)
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    app.setOrganizationName("Yak Shave")
    app.setStyle(YakStyle("Fusion"))
    app.setPalette(build_palette())
    app.setFont(ui_font(10))
    app.setStyleSheet(build_stylesheet())

    logo = load_logo_pixmap(256)
    if logo:
        app.setWindowIcon(QIcon(logo))

    store = Store(default_config_path())

    if not store.folders:
        welcome = WelcomeDialog(store)
        if welcome.exec() != QDialog.Accepted or not store.folders:
            return 0

    window = MainWindow(store)
    window.show()
    return app.exec()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException as startup_error:      # noqa: BLE001 - last line of defence
        report_startup_failure(startup_error)
        raise SystemExit(1)
