@echo off
setlocal enabledelayedexpansion
title Yak Shave
rem Starts yakshave_launcher.py with a visible console, so errors stay on screen.
rem Picks the Python installation that actually HAS PySide6 - not just the
rem newest one, and never the bare name "python.exe" (that is Windows'
rem Microsoft Store alias, not a Python installation).

cd /d "%~dp0"
set "FOUND="
set "NEWEST="
set "BEST="

rem A path in python_path.txt is only trusted if PySide6 is actually there -
rem an older version of Check Setup could have written one that isn't.
if exist "%~dp0python_path.txt" (
    set /p CUSTOM=<"%~dp0python_path.txt"
    if exist "!CUSTOM!" (
        "!CUSTOM!" -c "import PySide6" >nul 2>&1
        if not errorlevel 1 set "FOUND=!CUSTOM!"
    )
)

if not defined FOUND (
    for %%V in (314 313 312 311 310 39) do (
        call :probe "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
        call :probe "C:\Program Files\Python%%V\python.exe"
        call :probe "C:\Python%%V\python.exe"
    )
    if defined BEST set "FOUND=!BEST!"
)

if not defined FOUND if defined NEWEST set "FOUND=!NEWEST!"

if not defined FOUND (
    echo No Python installation found.
    echo.
    echo Install Python 3.10+ from python.org ^(not the Microsoft Store^),
    echo or put the full path to your python.exe into python_path.txt.
    echo.
    echo Run "Check Setup.bat" for a detailed report.
    echo.
    pause
    exit /b 1
)

echo Starting with: !FOUND!
echo.
"!FOUND!" "%~dp0yakshave_launcher.py"
if errorlevel 1 (
    echo.
    echo ---------------------------------------------------------------
    echo It did not start. Check the message above, and
    echo yakshave_error.log in this folder.
    echo.
    echo If PySide6 is missing, the easiest fix is to run:
    echo     Check Setup.bat
    echo It finds the right Python and can install PySide6 for you.
    echo ---------------------------------------------------------------
    pause
)
exit /b 0

:probe
if not exist %1 goto :eof
set "THIS=%~1"
if not defined NEWEST set "NEWEST=!THIS!"
%1 -c "import PySide6" >nul 2>&1
if not errorlevel 1 if not defined BEST set "BEST=!THIS!"
goto :eof
