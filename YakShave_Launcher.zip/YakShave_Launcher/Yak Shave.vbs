'
' Yak Shave - double-click starter for Windows.
'
' Finds a real Python installation itself and prefers the one that actually
' HAS PySide6 installed. It deliberately never calls the bare name
' "python.exe": Windows ships an App Execution Alias by that name which only
' opens the Microsoft Store, and that alias shadows real installations.
'
' Search order:
'   1. python_path.txt next to this file, if you put a path in it
'   2. an installation that has PySide6, newest first
'   3. the newest installation found at all
'   4. py.exe, the official Python launcher
'
' If nothing works you get a message box explaining what to do.

Option Explicit
Dim shell, fso, folder, target, python, result, command

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

folder = fso.GetParentFolderName(WScript.ScriptFullName)
target = folder & "\yakshave_launcher.py"

If Not fso.FileExists(target) Then
    MsgBox "yakshave_launcher.py was not found next to this file." & vbCrLf & vbCrLf & _
           "Keep this starter in the same folder as the app.", 16, "Yak Shave"
    WScript.Quit 1
End If

python = FindPython(folder)

If python = "" Then
    MsgBox "No Python installation was found." & vbCrLf & vbCrLf & _
           "Install Python 3.10 or newer from python.org (not the Microsoft " & _
           "Store) and tick ""Add Python to PATH"" during setup." & vbCrLf & vbCrLf & _
           "Then run 'Check Setup.bat' in this folder - it installs PySide6 " & _
           "into the right Python for you.", 16, "Yak Shave"
    WScript.Quit 1
End If

shell.CurrentDirectory = folder
command = """" & python & """ """ & target & """"
result = shell.Run(command, 0, True)

If result <> 0 Then
    MsgBox "Yak Shave stopped with an error." & vbCrLf & vbCrLf & _
           "Python used:" & vbCrLf & python & vbCrLf & vbCrLf & _
           "Most likely PySide6 is missing there." & vbCrLf & vbCrLf & _
           "Easiest fix: run 'Check Setup.bat' in this folder. It finds the " & _
           "right Python and can install PySide6 for you." & vbCrLf & vbCrLf & _
           "Or run 'Yak Shave.bat' to see the error message on screen.", 48, "Yak Shave"
End If

' ---------------------------------------------------------------------------

Function FindPython(baseFolder)
    Dim fso2, shell2, custom, stream, localApp, versions, i, probe, newest
    Dim windowless, candidates, c
    Set fso2 = CreateObject("Scripting.FileSystemObject")
    Set shell2 = CreateObject("WScript.Shell")
    FindPython = ""
    newest = ""

    ' 1. an explicit path you wrote down yourself - always wins
    If fso2.FileExists(baseFolder & "\python_path.txt") Then
        Set stream = fso2.OpenTextFile(baseFolder & "\python_path.txt", 1)
        If Not stream.AtEndOfStream Then custom = Trim(stream.ReadLine)
        stream.Close
        ' Only trusted if PySide6 is really there - an older Check Setup
        ' could have written a path that cannot run the app.
        If custom <> "" And fso2.FileExists(custom) Then
            If shell2.Run("""" & custom & """ -c ""import PySide6""", 0, True) = 0 Then
                windowless = Replace(custom, "\python.exe", "\pythonw.exe")
                If fso2.FileExists(windowless) Then
                    FindPython = windowless
                Else
                    FindPython = custom
                End If
                Exit Function
            End If
        End If
    End If

    ' 2. collect what is installed, newest first
    localApp = shell2.ExpandEnvironmentStrings("%LOCALAPPDATA%")
    versions = Array("314", "313", "312", "311", "310", "39")
    candidates = Array()
    For i = 0 To UBound(versions)
        AddIfExists candidates, fso2, localApp & "\Programs\Python\Python" & versions(i) & "\python.exe"
        AddIfExists candidates, fso2, "C:\Program Files\Python" & versions(i) & "\python.exe"
        AddIfExists candidates, fso2, "C:\Python" & versions(i) & "\python.exe"
    Next

    ' 3. prefer one that actually has PySide6
    For i = 0 To UBound(candidates)
        c = candidates(i)
        If newest = "" Then newest = c
        If shell2.Run("""" & c & """ -c ""import PySide6""", 0, True) = 0 Then
            windowless = Replace(c, "\python.exe", "\pythonw.exe")
            If fso2.FileExists(windowless) Then
                FindPython = windowless
            Else
                FindPython = c
            End If
            Exit Function
        End If
    Next

    ' 4. nothing has it - fall back to the newest, so the app can report why
    If newest <> "" Then
        windowless = Replace(newest, "\python.exe", "\pythonw.exe")
        If fso2.FileExists(windowless) Then
            FindPython = windowless
        Else
            FindPython = newest
        End If
        Exit Function
    End If

    ' 5. the official Python launcher, as a last resort
    If fso2.FileExists("C:\Windows\py.exe") Then FindPython = "C:\Windows\py.exe"
End Function

Sub AddIfExists(ByRef list, fso2, path)
    Dim size
    If Not fso2.FileExists(path) Then Exit Sub
    size = UBound(list) + 1
    ReDim Preserve list(size)
    list(size) = path
End Sub
