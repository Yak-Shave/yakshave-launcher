# Yak Shave Launcher

**Lightweight, no-bullshit CLI tools and Python scripts for power users.**

A control centre for your own scripts. Point it at a folder, and every script
in there shows up as a card: searchable, sortable, categorised, one click
from running. Drop in a new script and it appears — nothing to register,
nothing to configure, no edits to the launcher itself.

This is the **launcher only** — the free frame every Yak Shave tool runs in.
Individual tools (watermarking, duplicate finding, document formatting,
and so on) are released separately.

---

## Requirements

- **Python 3.10 or newer** — [python.org/downloads](https://python.org/downloads)
- **PySide6** — the only dependency, installed with one command (below)
- Windows, macOS, or Linux

## Setup

1. **Install Python 3.10+** if you don't already have it. On Windows, grab
   the installer from python.org rather than the Microsoft Store version —
   tick "Add python.exe to PATH" during install.
2. **Unzip this package** anywhere you like — your Desktop, Documents,
   wherever. Everything the launcher needs lives in this one folder.
3. **Install the one dependency:**
   ```
   pip install PySide6
   ```
4. **Start the launcher:**
   - Windows — double-click `Yak Shave.vbs` (no console window) or
     `Yak Shave.bat` (visible console, useful the first time in case
     something needs troubleshooting)
   - macOS / Linux — `python3 yakshave_launcher.py`
5. On first launch, a dialog asks for the folder your scripts live in. Pick
   any folder — it doesn't need to be this one. Point it at wherever you
   keep (or will keep) your own scripts.

That's it — no installer, no registry entries, nothing written outside this
folder until you run a script.

**Desktop shortcut:** once it's running, `Settings → Create desktop
shortcut` adds a proper icon on your Desktop for next time.

**Windows note:** the `.vbs`/`.bat` starters deliberately avoid calling
Python by the bare name `python.exe` — Windows ships a Microsoft Store
alias under that exact name that shadows a real install. The starters
search actual Python installations for one that has PySide6, rather than
just grabbing the newest version found.

---

## Describe your own scripts

Add a short header to the top of any script — comment style or docstring,
both work:

```python
# Name: Watermark Batch
# Category: Images
# Description: Applies an adaptive watermark to every image in a folder.
# Version: 1.4
# Tags: batch, images, watermark
# Args: --input . --dry-run
```

Every field is optional. Without a header, the launcher still lists the
script and falls back to the file name and subfolder name.

| Field | What it does |
|---|---|
| `Name` | Card title |
| `Category` | Sidebar grouping |
| `Description` | The line shown on the card |
| `Author`, `Version` | Shown in the details panel |
| `Tags` | Comma separated, included in search |
| `Icon` | One or two characters for the card badge |
| `Args` | Pre-filled arguments |
| `Requires` | Informational note about dependencies |
| `Terminal: true` | Always launch in a real terminal window |
| `Hidden: true` | Keep helper modules out of the library |
| `Order` | Integer that pulls a script up in name sorting |
| `Suite` / `Suite-Order` / `Suite-Role` | Groups related scripts into a suite with a shared hub (see below) |

Copy `_script_template.py` to start a new tool with the header already in
place.

### Suites

A few scripts that belong to one larger task can be grouped into a
**suite**: give each one a `Suite: <name>` header, an order, and mark one
as the hub with `Suite-Role: hub`. The launcher automatically gives the
suite its own section in the sidebar, its own view (hub first, then the
rest in order), and a suite badge on each card. No launcher changes needed
— it's all read from the headers, same as everything else.

---

## What it does

- Watches your script folders and picks up changes as they happen
- Sorts by date modified, name, category, last run, or times run
- Favourites, full-text search across names, tags, and descriptions
- Runs `.py`, `.pyw`, `.bat`, `.cmd`, `.ps1`, and `.sh`
- Live console with one tab per run, several runs at once, and an input
  box so interactive command-line tools stay usable
- Remembers arguments per script, plus how often and when you last ran it
- Multiple script folders at once, configurable Python interpreter
- Groups related scripts into suites with a shared hub, when a script's
  header says so

## Shortcuts

`Ctrl+F` search · `F5` rescan · `F8` console · `Ctrl+,` settings ·
`Esc` clear search · `Ctrl+Q` quit

## Where settings live

`yakshave_data/` next to the launcher — the same folder every Yak Shave
tool writes into, so a folder of scripts stays a folder of scripts.
Portable: move the folder, keep your setup. Set `YAKSHAVE_DATA_DIR` to put
it elsewhere; if the launcher's own folder turns out to be read-only, it
falls back to `~/.yakshave/` automatically.

## Files in this package

| File | What it's for |
|---|---|
| `yakshave_launcher.py` | The application. Everything lives in this one file. |
| `yakshave_assets.py` | The Yak Shave logo, embedded — delete only if you don't care about the icon. |
| `Yak Shave.vbs` | Windows starter, no console window. |
| `Yak Shave.bat` | Windows starter, visible console — useful for the first run. |
| `_script_template.py` | Starting point for your own tools, header pre-filled. |
